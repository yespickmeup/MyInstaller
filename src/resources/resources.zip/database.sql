-- MySQL dump 10.13  Distrib 5.6.20, for Win32 (x86)
--
-- Host: localhost    Database: db_fortune_three
-- ------------------------------------------------------
-- Server version	5.5.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_fortune_three`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_fortune_three` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_fortune_three`;

--
-- Table structure for table `banks`
--

DROP TABLE IF EXISTS `banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banks`
--

LOCK TABLES `banks` WRITE;
/*!40000 ALTER TABLE `banks` DISABLE KEYS */;
INSERT INTO `banks` VALUES (1,'BANK OF THE PHILIPPINE ISLAND'),(2,'BANKO PILIPINO'),(3,'CHINA BANK'),(4,'METROBANK'),(5,'VETERANS BANK'),(6,'ALLIED BANK'),(7,'PPA CHIT');
/*!40000 ALTER TABLE `banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barcodes`
--

DROP TABLE IF EXISTS `barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barcodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barcodes`
--

LOCK TABLES `barcodes` WRITE;
/*!40000 ALTER TABLE `barcodes` DISABLE KEYS */;
INSERT INTO `barcodes` VALUES (3,'CM0000000001'),(4,'CM1'),(5,'CM2'),(6,'CM3');
/*!40000 ALTER TABLE `barcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_drawer`
--

DROP TABLE IF EXISTS `cash_drawer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_drawer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_no` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `screen_name` varchar(100) DEFAULT NULL,
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `cash_out` double DEFAULT NULL,
  `thousand` double DEFAULT NULL,
  `five_hundred` double DEFAULT NULL,
  `two_hundred` double DEFAULT NULL,
  `fifty` double DEFAULT NULL,
  `twenty` double DEFAULT NULL,
  `coins` double DEFAULT NULL,
  `one_hundred` double DEFAULT NULL,
  `expenses` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_drawer`
--

LOCK TABLES `cash_drawer` WRITE;
/*!40000 ALTER TABLE `cash_drawer` DISABLE KEYS */;
INSERT INTO `cash_drawer` VALUES (12,'CD-00000000002','cashier','Cashier Name','2013-06-21 15:09:11','2013-06-21 15:42:42',1000,0,11,22,33,55,66,77,44,0),(14,'CD-00000000003','lily1','Lily Vilando','2013-06-21 16:28:19',NULL,900,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(15,'CD-00000000004','cashier','Cashier Name','2013-06-22 11:48:09',NULL,100,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(16,'CD-00000000005','cashier','Cashier Name','2013-06-26 08:59:07','2013-06-26 14:50:41',100,0,1,1,1,1,5,49,1,0),(17,'CD-00000000006','lily','Lily Vilando','2013-06-26 14:51:35','2013-06-26 15:26:00',1000,0,2,9,3,10,26,0,25,0),(18,'CD-00000000007','lily','Lily Vilando','2013-06-27 09:44:13',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(19,'CD-00000000008','lily','Lily Vilando','2013-06-28 08:18:05',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(20,'CD-00000000009','lily','Lily Vilando','2013-06-29 08:03:23','2013-06-29 18:10:32',1000,0,18,15,0,13,1,6.4,3,0),(21,'CD-00000000010','lily','Lily Vilando','2013-07-01 08:33:12',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(22,'CD-00000000011','lily','Lily Vilando','2013-07-02 08:03:42',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(23,'CD-00000000012','lily','Lily Vilando','2013-07-04 11:01:13','2013-07-04 16:04:32',1100,0,1,2,1,1,1,10.75,1,0),(34,'CD-00000000013','lily','Lily Vilando','2013-07-08 00:25:30','2013-07-08 00:25:46',1000,0,1,2,2,0,0,0,0,0),(35,'CD-00000000014','sample','Sample','2013-07-13 14:59:00',NULL,6000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(36,'CD-00000000015','lily','Lily Vilando','2013-07-24 09:32:16',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,'CD-00000000016','lily','Lily Vilando','2013-07-26 22:23:38',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,'CD-00000000017','cashier','Cashier Name','2013-08-25 16:04:57',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,'CD-00000000018','cashier','Cashier Name','2013-09-02 14:11:53',NULL,1000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cash_drawer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_drawer_checks`
--

DROP TABLE IF EXISTS `cash_drawer_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_drawer_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_no` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `screen_name` varchar(100) DEFAULT NULL,
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `bank` varchar(100) DEFAULT NULL,
  `check_no` varchar(100) DEFAULT NULL,
  `check_holder` varchar(100) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_drawer_checks`
--

LOCK TABLES `cash_drawer_checks` WRITE;
/*!40000 ALTER TABLE `cash_drawer_checks` DISABLE KEYS */;
INSERT INTO `cash_drawer_checks` VALUES (9,'CD-00000000002','cashier','Cashier Name','2013-06-21 15:41:30','2013-06-21 15:41:30','CHINA BANK','','',200),(10,'CD-00000000002','cashier','Cashier Name','2013-06-21 15:43:06','2013-06-21 15:43:06','ALLIED BANK','','',1000),(11,'CD-00000000002','cashier','Cashier Name','2013-06-21 15:44:51','2013-06-21 15:44:51','BANK OF THE PHILIPPINE ISLAND','','',10000),(12,'CD-00000000005','cashier','Cashier Name','2013-06-26 14:50:33','2013-06-26 14:50:33','VETERANS BANK','','',1000),(13,'CD-00000000005','cashier','Cashier Name','2013-06-26 14:50:37','2013-06-26 14:50:37','METROBANK','','',200),(14,'CD-00000000006','lily','Lily Vilando','2013-06-26 14:56:27','2013-06-26 14:56:27','ALLIED BANK','','',2000),(15,'CD-00000000006','lily','Lily Vilando','2013-06-26 15:25:13','2013-06-26 15:25:13','bpi','','',500),(16,'CD-00000000006','lily','Lily Vilando','2013-06-26 15:25:26','2013-06-26 15:25:26','cang','','',150),(17,'CD-00000000006','lily','Lily Vilando','2013-06-26 15:25:38','2013-06-26 15:25:38','snack','','',18),(18,'CD-00000000009','lily','Lily Vilando','2013-06-29 08:03:23','2013-06-29 16:29:57','bpi','','',1500),(19,'CD-00000000009','lily','Lily Vilando','2013-06-29 08:03:23','2013-06-29 16:32:55','land bank','','',7270),(20,'CD-00000000009','lily','Lily Vilando','2013-06-29 08:03:23','2013-06-29 16:34:12','snack','','',18),(26,'CD-00000000013','lily','Lily Vilando','2013-07-08 00:25:30','2013-07-08 00:25:39','BANK OF THE PHILIPPINE ISLAND','','',1000),(27,'CD-00000000013','lily','Lily Vilando','2013-07-08 00:25:30','2013-07-08 00:26:51','CHINA BANK','','',500);
/*!40000 ALTER TABLE `cash_drawer_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_drawer_expenses`
--

DROP TABLE IF EXISTS `cash_drawer_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_drawer_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_no` varchar(500) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `screen_name` varchar(500) DEFAULT NULL,
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `bank` varchar(500) DEFAULT NULL,
  `check_no` varchar(500) DEFAULT NULL,
  `check_holder` varchar(500) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_drawer_expenses`
--

LOCK TABLES `cash_drawer_expenses` WRITE;
/*!40000 ALTER TABLE `cash_drawer_expenses` DISABLE KEYS */;
INSERT INTO `cash_drawer_expenses` VALUES (2,'CD-00000000013','lily','Lily Vilando','2013-07-08 00:25:30','2013-07-08 00:25:45','BILLS','','',50,'2013-07-08 00:25:30'),(3,'CD-00000000013','lily','Lily Vilando','2013-07-08 00:25:30','2013-07-08 00:26:59','DELIVERY','','',20,'2013-07-08 00:25:30');
/*!40000 ALTER TABLE `cash_drawer_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `check_holders`
--

DROP TABLE IF EXISTS `check_holders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_holders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `holder_name` varchar(100) DEFAULT NULL,
  `holder_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=271 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `check_holders`
--

LOCK TABLES `check_holders` WRITE;
/*!40000 ALTER TABLE `check_holders` DISABLE KEYS */;
INSERT INTO `check_holders` VALUES (1,'Ronald Pascua','1212121'),(2,'Holder','000001'),(4,'',''),(5,'',''),(6,'',''),(7,'',''),(8,'',''),(9,'STA TERESA',''),(10,'',''),(11,'',''),(12,'',''),(13,'',''),(14,'',''),(15,'',''),(16,'',''),(17,'',''),(18,'',''),(19,'',''),(20,'',''),(21,'',''),(22,'',''),(23,'',''),(24,'',''),(25,'',''),(26,'',''),(27,'',''),(28,'',''),(29,'',''),(30,'',''),(31,'',''),(32,'',''),(33,'',''),(34,'',''),(35,'',''),(36,'',''),(37,'',''),(38,'',''),(39,'',''),(40,'',''),(41,'',''),(42,'',''),(43,'',''),(44,'',''),(45,'',''),(46,'',''),(47,'',''),(48,'',''),(49,'',''),(50,'',''),(51,'',''),(52,'',''),(53,'',''),(54,'',''),(55,'',''),(56,'',''),(57,'',''),(58,'',''),(59,'',''),(60,'',''),(61,'',''),(62,'',''),(63,'',''),(64,'',''),(65,'',''),(66,'',''),(67,'',''),(68,'',''),(69,'',''),(70,'',''),(71,'',''),(72,'',''),(73,'',''),(74,'',''),(75,'',''),(76,'',''),(77,'',''),(78,'',''),(79,'',''),(80,'',''),(81,'',''),(82,'',''),(83,'',''),(84,'',''),(85,'',''),(86,'',''),(87,'',''),(88,'',''),(89,'',''),(90,'',''),(91,'',''),(92,'',''),(93,'',''),(94,'',''),(95,'',''),(96,'',''),(97,'',''),(98,'',''),(99,'',''),(100,'',''),(101,'',''),(102,'',''),(103,'',''),(104,'',''),(105,'',''),(106,'',''),(107,'',''),(108,'',''),(109,'',''),(110,'',''),(111,'',''),(112,'',''),(113,'',''),(114,'',''),(115,'',''),(116,'',''),(117,'',''),(118,'',''),(119,'',''),(120,'',''),(121,'',''),(122,'',''),(123,'HOY LUGAW','0125206'),(124,'',''),(125,'',''),(126,'',''),(127,'',''),(128,'',''),(129,'',''),(130,'',''),(131,'',''),(132,'',''),(133,'',''),(134,'',''),(135,'',''),(136,'',''),(137,'',''),(138,'',''),(139,'',''),(140,'',''),(141,'',''),(142,'',''),(143,'',''),(144,'',''),(145,'',''),(146,'',''),(147,'',''),(148,'',''),(149,'',''),(150,'',''),(151,'',''),(152,'',''),(153,'',''),(154,'',''),(155,'',''),(156,'',''),(157,'',''),(158,'',''),(159,'',''),(160,'',''),(161,'',''),(162,'',''),(163,'',''),(164,'',''),(165,'',''),(166,'',''),(167,'',''),(168,'',''),(169,'',''),(170,'',''),(171,'',''),(172,'',''),(173,'',''),(174,'',''),(175,'',''),(176,'',''),(177,'',''),(178,'',''),(179,'',''),(180,'',''),(181,'',''),(182,'',''),(183,'',''),(184,'',''),(185,'',''),(186,'',''),(187,'',''),(188,'',''),(189,'',''),(190,'',''),(191,'',''),(192,'',''),(193,'',''),(194,'',''),(195,'',''),(196,'',''),(197,'',''),(198,'',''),(199,'',''),(200,'',''),(201,'',''),(202,'',''),(203,'',''),(204,'',''),(205,'',''),(206,'',''),(207,'',''),(208,'',''),(209,'',''),(210,'',''),(211,'',''),(212,'',''),(213,'',''),(214,'',''),(215,'',''),(216,'',''),(217,'',''),(218,'',''),(219,'',''),(220,'',''),(221,'',''),(222,'',''),(223,'',''),(224,'',''),(225,'',''),(226,'',''),(227,'',''),(228,'',''),(229,'',''),(230,'',''),(231,'',''),(232,'',''),(233,'',''),(234,'',''),(235,'',''),(236,'',''),(237,'',''),(238,'',''),(239,'',''),(240,'',''),(241,'',''),(242,'',''),(243,'',''),(244,'',''),(245,'',''),(246,'',''),(247,'',''),(248,'',''),(249,'',''),(250,'',''),(251,'',''),(252,'',''),(253,'',''),(254,'',''),(255,'',''),(256,'',''),(257,'',''),(258,'',''),(259,'',''),(260,'',''),(261,'',''),(262,'',''),(263,'',''),(264,'',''),(265,'',''),(266,'',''),(267,'',''),(268,'',''),(269,'',''),(270,'','');
/*!40000 ALTER TABLE `check_holders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classification`
--

DROP TABLE IF EXISTS `classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `classification` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classification`
--

LOCK TABLES `classification` WRITE;
/*!40000 ALTER TABLE `classification` DISABLE KEYS */;
/*!40000 ALTER TABLE `classification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (2,'jolibee'),(4,'customer2'),(10,'ronald pascua'),(11,'ronald pascua2'),(12,'sample'),(13,''),(14,'lee super plaza'),(15,''),(16,'rosana magdalan'),(17,''),(18,''),(19,''),(20,''),(21,''),(22,''),(23,''),(24,''),(25,''),(26,''),(27,''),(28,''),(29,''),(30,''),(31,''),(32,''),(33,''),(34,''),(35,''),(36,''),(37,''),(38,''),(39,''),(40,''),(41,''),(42,''),(43,''),(44,''),(45,''),(46,''),(47,'PASTA KING'),(48,''),(49,''),(50,'SCOOBYS'),(51,''),(52,''),(53,'EDA ZENAIDA PAGUIO'),(54,'PARADISE'),(55,''),(56,''),(57,''),(58,''),(59,''),(60,''),(61,'crown traders'),(62,'girlie bernaldez'),(63,''),(64,''),(65,''),(66,''),(67,''),(68,''),(69,''),(70,''),(71,''),(72,''),(73,''),(74,'fidela cornel'),(75,''),(76,''),(77,''),(78,'ANTULANG'),(79,''),(80,'judith maquiling'),(81,''),(82,''),(83,''),(84,''),(85,''),(86,''),(87,''),(88,''),(89,''),(90,''),(91,''),(92,''),(93,''),(94,''),(95,''),(96,''),(97,''),(98,'FLIMAN GRILL'),(99,''),(100,''),(101,''),(102,''),(103,''),(104,''),(105,''),(106,''),(107,''),(108,''),(109,''),(110,''),(111,''),(112,''),(113,''),(114,''),(115,''),(116,''),(117,''),(118,''),(119,''),(120,''),(121,''),(122,''),(123,''),(124,''),(125,''),(126,''),(127,''),(128,''),(129,''),(130,''),(131,''),(132,''),(133,''),(134,''),(135,''),(136,''),(137,''),(138,''),(139,''),(140,''),(141,'ubp'),(142,'FOOD TOWN'),(143,''),(144,''),(145,''),(146,''),(147,''),(148,''),(149,''),(150,''),(151,''),(152,''),(153,''),(154,''),(155,''),(156,''),(157,'CANGS'),(158,''),(159,''),(160,''),(161,''),(162,''),(163,''),(164,''),(165,'meliton gabas'),(166,''),(167,''),(168,''),(169,''),(170,''),(171,''),(172,''),(173,''),(174,''),(175,''),(176,''),(177,''),(178,''),(179,''),(180,''),(181,''),(182,''),(183,''),(184,''),(185,''),(186,''),(187,''),(188,''),(189,''),(190,''),(191,''),(192,''),(193,''),(194,''),(195,''),(196,''),(197,''),(198,''),(199,'kamalig'),(200,''),(201,''),(202,''),(203,''),(204,''),(205,''),(206,'cadiz'),(207,''),(208,''),(209,'holy cross'),(210,''),(211,'ERWIN QUIAMCO'),(212,''),(213,''),(214,''),(215,''),(216,'archer'),(217,''),(218,''),(219,''),(220,''),(221,''),(222,''),(223,''),(224,''),(225,''),(226,''),(227,''),(228,''),(229,''),(230,''),(231,''),(232,'DON BOSCO'),(233,'CHIN LOONG'),(234,''),(235,''),(236,''),(237,'F NACUA'),(238,''),(239,'KYOSKO'),(240,''),(241,''),(242,''),(243,''),(244,''),(245,''),(246,''),(247,''),(248,''),(249,''),(250,''),(251,''),(252,''),(253,''),(254,''),(255,''),(256,''),(257,''),(258,''),(259,''),(260,'3z store'),(261,''),(262,''),(263,''),(264,''),(265,''),(266,''),(267,''),(268,''),(269,''),(270,''),(271,''),(272,''),(273,''),(274,''),(275,''),(276,''),(277,''),(278,''),(279,''),(280,''),(281,''),(282,''),(283,''),(284,''),(285,'sco'),(286,'EDELWEISE'),(287,''),(288,''),(289,''),(290,''),(291,''),(292,''),(293,''),(294,''),(295,''),(296,''),(297,''),(298,''),(299,''),(300,'');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_customers`
--

DROP TABLE IF EXISTS `discount_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) DEFAULT NULL,
  `id_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_customers`
--

LOCK TABLES `discount_customers` WRITE;
/*!40000 ALTER TABLE `discount_customers` DISABLE KEYS */;
INSERT INTO `discount_customers` VALUES (1,'Juan Dela Cruz','0000000111'),(2,'Maria Antony','0000022'),(3,'Piolo Pascual','0000023'),(4,'janice','1000'),(5,'',''),(6,'',''),(7,'',''),(8,'',''),(9,'',''),(10,'Ronald Pascua','00000001'),(11,'rrr','1000'),(12,'',''),(13,'',''),(14,'leandro catan','1650'),(15,'',''),(16,'',''),(17,'',''),(18,'',''),(19,'',''),(20,'',''),(21,'',''),(22,'',''),(23,'',''),(24,'',''),(25,'',''),(26,'',''),(27,'',''),(28,'',''),(29,'',''),(30,'',''),(31,'',''),(32,'',''),(33,'',''),(34,'',''),(35,'',''),(36,'',''),(37,'',''),(38,'',''),(39,'',''),(40,'',''),(41,'',''),(42,'',''),(43,'',''),(44,'',''),(45,'',''),(46,'',''),(47,'',''),(48,'',''),(49,'',''),(50,'',''),(51,'',''),(52,'',''),(53,'',''),(54,'',''),(55,'',''),(56,'',''),(57,'',''),(58,'',''),(59,'',''),(60,'',''),(61,'',''),(62,'',''),(63,'',''),(64,'',''),(65,'',''),(66,'',''),(67,'',''),(68,'',''),(69,'',''),(70,'',''),(71,'',''),(72,'',''),(73,'',''),(74,'',''),(75,'',''),(76,'',''),(77,'',''),(78,'',''),(79,'',''),(80,'',''),(81,'',''),(82,'',''),(83,'',''),(84,'',''),(85,'',''),(86,'',''),(87,'',''),(88,'',''),(89,'',''),(90,'',''),(91,'',''),(92,'',''),(93,'',''),(94,'',''),(95,'',''),(96,'',''),(97,'',''),(98,'',''),(99,'',''),(100,'',''),(101,'',''),(102,'',''),(103,'',''),(104,'',''),(105,'',''),(106,'',''),(107,'',''),(108,'',''),(109,'',''),(110,'',''),(111,'',''),(112,'',''),(113,'',''),(114,'',''),(115,'',''),(116,'',''),(117,'',''),(118,'',''),(119,'',''),(120,'',''),(121,'',''),(122,'',''),(123,'',''),(124,'',''),(125,'',''),(126,'',''),(127,'',''),(128,'',''),(129,'',''),(130,'',''),(131,'',''),(132,'',''),(133,'',''),(134,'',''),(135,'',''),(136,'',''),(137,'',''),(138,'',''),(139,'',''),(140,'',''),(141,'',''),(142,'',''),(143,'',''),(144,'',''),(145,'',''),(146,'',''),(147,'',''),(148,'',''),(149,'',''),(150,'',''),(151,'',''),(152,'',''),(153,'',''),(154,'',''),(155,'COCO GRANDE',''),(156,'APO ISLAND',''),(157,'',''),(158,'',''),(159,'',''),(160,'',''),(161,'',''),(162,'',''),(163,'',''),(164,'',''),(165,'',''),(166,'',''),(167,'',''),(168,'',''),(169,'',''),(170,'',''),(171,'',''),(172,'',''),(173,'',''),(174,'',''),(175,'',''),(176,'',''),(177,'',''),(178,'',''),(179,'',''),(180,'',''),(181,'',''),(182,'',''),(183,'',''),(184,'',''),(185,'',''),(186,'',''),(187,'',''),(188,'',''),(189,'',''),(190,'',''),(191,'',''),(192,'',''),(193,'',''),(194,'',''),(195,'',''),(196,'',''),(197,'',''),(198,'',''),(199,'',''),(200,'',''),(201,'',''),(202,'',''),(203,'',''),(204,'',''),(205,'',''),(206,'',''),(207,'',''),(208,'',''),(209,'',''),(210,'',''),(211,'',''),(212,'',''),(213,'',''),(214,'',''),(215,'',''),(216,'',''),(217,'',''),(218,'',''),(219,'',''),(220,'',''),(221,'',''),(222,'',''),(223,'',''),(224,'',''),(225,'',''),(226,'',''),(227,'',''),(228,'',''),(229,'',''),(230,'',''),(231,'',''),(232,'',''),(233,'',''),(234,'',''),(235,'',''),(236,'',''),(237,'',''),(238,'',''),(239,'',''),(240,'',''),(241,'',''),(242,'',''),(243,'',''),(244,'',''),(245,'',''),(246,'',''),(247,'',''),(248,'',''),(249,'',''),(250,'',''),(251,'',''),(252,'',''),(253,'',''),(254,'',''),(255,'',''),(256,'',''),(257,'',''),(258,'',''),(259,'',''),(260,'',''),(261,'',''),(262,'',''),(263,'',''),(264,'',''),(265,'',''),(266,'',''),(267,'',''),(268,'',''),(269,'o','0000022'),(270,'',''),(271,'',''),(272,'',''),(273,'',''),(274,'',''),(275,'',''),(276,'',''),(277,'',''),(278,'','');
/*!40000 ALTER TABLE `discount_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts`
--

DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discount_name` varchar(100) DEFAULT NULL,
  `discount_rate` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts`
--

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
INSERT INTO `discounts` VALUES (1,'NO DISCOUNT',0),(2,'REGULAR CUSTOMER',50),(3,'SENIOR CITIZEN',5),(4,'WITHOLDING TAX ',1);
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,'TRANSPORTATION'),(2,'DELIVERY'),(3,'SNACKS'),(4,'BILLS');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_categories`
--

DROP TABLE IF EXISTS `inv_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inv_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_categories`
--

LOCK TABLES `inv_categories` WRITE;
/*!40000 ALTER TABLE `inv_categories` DISABLE KEYS */;
INSERT INTO `inv_categories` VALUES (5,'FROZEN '),(6,'VEGETABLES'),(7,'SUGAR'),(8,'RICE'),(9,'EGGS'),(10,'FRESH MEAT'),(11,'DRIED FISH'),(12,'SPICES'),(13,'SALT'),(14,'FRUITS');
/*!40000 ALTER TABLE `inv_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_classifications`
--

DROP TABLE IF EXISTS `inv_classifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inv_classifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(100) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `classification` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_classifications`
--

LOCK TABLES `inv_classifications` WRITE;
/*!40000 ALTER TABLE `inv_classifications` DISABLE KEYS */;
INSERT INTO `inv_classifications` VALUES (1,'1','category1','class1'),(2,'1','category1','class11'),(3,'2','category2','class2'),(4,'2','category2','class22');
/*!40000 ALTER TABLE `inv_classifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_sub_classifications`
--

DROP TABLE IF EXISTS `inv_sub_classifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inv_sub_classifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(100) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `classification_name` varchar(100) DEFAULT NULL,
  `sub_classification` varchar(100) DEFAULT NULL,
  `classification_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_sub_classifications`
--

LOCK TABLES `inv_sub_classifications` WRITE;
/*!40000 ALTER TABLE `inv_sub_classifications` DISABLE KEYS */;
INSERT INTO `inv_sub_classifications` VALUES (1,'1','category1','class11','sub1','2');
/*!40000 ALTER TABLE `inv_sub_classifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_multi_level_pricing`
--

DROP TABLE IF EXISTS `item_multi_level_pricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_multi_level_pricing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `conversion` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_multi_level_pricing`
--

LOCK TABLES `item_multi_level_pricing` WRITE;
/*!40000 ALTER TABLE `item_multi_level_pricing` DISABLE KEYS */;
INSERT INTO `item_multi_level_pricing` VALUES (1,'CM0000000008','desc1','Item 1',5,500),(2,'CM4','desc2','Item 1',10,1000),(3,'CM0000000008','desc23','Item 1',2,100),(4,'EG','','BOX',5,10),(5,'EG','','TRUCK',10,20),(6,'EG','','BAG',15,30),(9,'EXL','','TRAY-12',12,77.6),(10,'EXL','','TRAY-30',30,170),(11,'EXL','','TRAY-6',6,38.8),(12,'EL3','','TRAY-30',30,150),(13,'EL3','','TRAY-12',12,71.6),(14,'EL3','','TRAY-6',6,35.8),(15,'EM','','TRAY-30',30,140),(16,'EM','','TRAY-12',12,68),(17,'EM','','TRAY-6',6,34),(18,'CM3','','2KLS',2,200),(19,'CM3','','1KL',1,100),(20,'CM3','','500G',0.5,50),(21,'CM3','','2KLS',2,200),(22,'CM3','','1KL',1,100),(23,'FF','','2KLS',2,200),(24,'FF','','1KL',1,100),(25,'FF','','500G',0.5,50),(26,'fp','','1KL',1,130),(27,'fp','','500G',0.5,65),(29,'RS','','1KL',1,42.7),(30,'RS','','500G',0.5,21.35),(31,'CS','','1KL',1,34.4),(32,'CS','','500G',0.5,17.2),(33,'SR','','2KLS',2,79),(34,'SR','','25KL',25,977),(35,'BAL','','2KLS',2,76.9),(36,'BAL','','25KL',25,924),(37,'GSR','','2KLS',2,0),(38,'GSR','','25KL',25,0),(39,'YDR','','2KLS',2,382),(40,'MO','','250G',0.25,15),(42,'S','','500G',0.5,3),(43,'EXL','','PC',1,5.8),(44,'4800282000080','','1KL',1,130),(46,'4800282000080','','500G',0.5,65),(47,'BAL','','1KL',1,38.45),(49,'GSR','','1KL',1,35.8),(50,'MO','','1KL',1,60),(51,'S','','1KL',1,6),(52,'SR','','1KL',1,39.5),(54,'YDR','','1KL',1,0),(55,'ES','','PC',1,4.75),(56,'ES','','TRAY-30',30,130),(57,'EM','','TRAY-30',1,5),(58,'EL3','','PC',1,5.3),(59,'EXL','','TRAY-15',15,85),(60,'EL3','','TRAY-15',15,75),(61,'EM','','TRAY-15',15,70),(62,'MO','','500G',0.5,30),(63,'MO','','SACK',25,1260),(64,'4800393000080','','PC',0,0),(65,'4800282000080','','250G',0.25,32.5),(66,'480000','','PC',0,0),(69,'WB','','1KL',1,70),(70,'WB','','500G',0.5,35),(71,'WB','','250G',0.25,17.5),(72,'WB','','25KL',25,1450),(73,'fp','','250G',0.25,32.5),(74,'YDR','','SACK',50,0),(75,'CS','','SACK',50,0),(76,'RS','','SACK',50,0),(77,'EL3','','TRAY-30',30,150),(78,'EL3','','TRAY-12',12,71.6),(79,'EL3','','TRAY-6',6,35.8),(80,'EL3','','PC',1,5.3),(81,'EL3','','TRAY-15',15,75),(82,'EL3','','TRAY-30',30,146),(83,'EL1','','PC',0,0),(84,'EL2','','PC',0,0),(85,'EL3','','TRAY-30',30,150),(86,'EL3','','TRAY-12',12,71.6),(87,'EL3','','TRAY-6',6,35.8),(88,'EL3','','PC',1,5.3),(89,'EL3','','TRAY-15',15,75),(90,'EL3','','TRAY-30',30,150),(91,'EL3','','TRAY-12',12,71.6),(92,'EL3','','TRAY-6',6,35.8),(93,'EL3','','PC',1,5.3),(94,'EL3','','TRAY-15',15,75),(95,'EL3','','TRAY-30',30,146),(96,'EL3','','TRAY-30',30,150),(97,'EL3','','TRAY-12',12,71.6),(98,'EL3','','TRAY-6',6,35.8),(99,'EL3','','PC',1,5.3),(100,'EL3','','TRAY-15',15,75),(101,'EL3','','TRAY-30',30,150),(102,'EL3','','TRAY-12',12,71.6),(103,'EL3','','TRAY-6',6,35.8),(104,'EL3','','PC',1,5.3),(105,'EL3','','TRAY-15',15,75),(106,'EL3','','TRAY-30',30,146),(107,'EL3','','TRAY-30',30,150),(108,'EL3','','TRAY-12',12,71.6),(109,'EL3','','TRAY-6',6,35.8),(110,'EL3','','PC',1,5.3),(111,'EL3','','TRAY-15',15,75),(112,'EL3','','TRAY-30',30,150),(113,'EL3','','TRAY-12',12,71.6),(114,'EL3','','TRAY-6',6,35.8),(115,'EL3','','PC',1,5.3),(116,'EL3','','TRAY-15',15,75),(117,'EL3','','TRAY-30',30,146),(118,'EL','','PC',1,5.3),(119,'EL','','TRAY-30',30,146),(120,'EL','','TRAY-30',30,150),(121,'EL','','TRAY-12',12,71.6),(122,'EL','','TRAY-6',6,35.8);
/*!40000 ALTER TABLE `item_multi_level_pricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `generic_name` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `classification` varchar(100) DEFAULT NULL,
  `classification_id` varchar(100) DEFAULT NULL,
  `sub_classification` varchar(100) DEFAULT NULL,
  `sub_classification_id` varchar(100) DEFAULT NULL,
  `product_qty` double DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `conversion` double DEFAULT NULL,
  `selling_price` double DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `item_type` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `fixed_price` int(11) DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `supplier_id` varchar(100) DEFAULT NULL,
  `multi_level_pricing` int(11) DEFAULT NULL,
  `vatable` int(11) DEFAULT NULL,
  `reorder_level` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (9,'4806518440002','SEA WORLD TEMPURA 1KL',' ','FROZEN ','0','','0','','0',-6,'PC',1,145.5,'2013-06-19 15:00:40','admin','',1,'SEA WORLD ',1,115,'0',0,0,1),(20,'fp','FROZEN PEAS',' ','FROZEN ','0','','0','','0',-8.25,'1KL',1,32.5,'2013-06-27 16:38:55','admin','',1,'S&R MEMBERSHIP',1,0,'0',1,0,1),(21,'4800282000080','MIXED VEGETABLES',' ','FROZEN ','0','','0','','0',57,'1KL',1,130,'2013-06-27 16:37:39','admin','',1,'S&R MEMBERSHIP',1,99.95,'0',1,0,1),(26,'4806518440040','SEA WORLD SQUID BALL 500G',' ','FROZEN ','0','','0','','0',10,'500G',1,88.5,'2013-06-26 16:11:09','admin','',1,'SEA WORLD ',1,70,'0',0,0,1),(27,'4806518440071','SEA WORLD SQUID ROLL 500G',' ','FROZEN ','0','','0','','0',20,'500G',1,88.5,'2013-06-26 16:11:16','admin','',1,'SEA WORLD ',1,70,'0',0,0,1),(33,'FB500','SEA WORLD FISH BALL 500G',' ','FROZEN ','0','','0','','0',20,'PC',1,72.75,'2013-06-19 14:54:21','admin','',1,'SEA WORLD ',1,55,'0',0,0,1),(42,'CW','CHICKEN WINGS',' ','FRESH MEAT','0','','0','','0',-1.6669999999999998,'KILO',1,143,'2013-06-27 17:01:30','admin','',1,'BOUNTY FRESH',0,0,'0',0,0,1),(47,'CT','CHICKEN THIGH',' ','FRESH MEAT','0','','0','','0',-3.352,'KILO',1,143,'2013-06-27 17:01:57','admin','',1,'BOUNTY FRESH',0,0,'0',0,0,1),(50,'CB','CHICKEN BREAST',' ','FRESH MEAT','0','','0','','0',19.68,'KILO',1,143,'2013-06-26 16:06:48','admin','',1,'BOUNTY FRESH',0,0,'0',0,0,1),(52,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',-23.938000000000002,'KILO',1,50,'2013-06-26 16:07:07','admin','',1,'BOUNTY FRESH',0,0,'0',0,0,1),(54,'CF','CHICKEN FILLET',' ','FRESH MEAT','0','','0','','0',0,'KILO',1,200,'2013-06-27 17:01:52','admin','',1,'BOUNTY FRESH',0,0,'0',0,0,1),(59,'EXL','EGGS X-LARGE',' ','EGGS','0','','0','','0',60,'1KL',1,5.8,'2013-06-26 16:27:33','admin','',1,'QUIAMCO FARM',1,4,'0',1,0,1),(70,'ES','EGGS SMALL',' ','EGGS','0','','0','','0',106,'PC',1,4.75,'2013-06-27 09:48:52','admin','',1,'QUIAMCO FARM',0,4.3,'0',1,0,1),(72,'EP','EGGS PEEWEE',' ','EGGS','0','','0','','0',1,'PC',1,4,'2013-06-27 17:02:41','admin','',1,'QUIAMCO FARM',1,3.8,'0',0,0,1),(74,'EC','EGGS CRACKED',' ','EGGS','0','','0','','0',6,'PC',1,3,'2013-06-28 10:44:35','admin','',1,'QUIAMCO FARM',1,0,'0',0,0,1),(76,'DFH','DRIED FISH HINOK',' ','DRIED FISH','0','','0','','0',0,'1KL',1,230,'2013-06-26 16:22:32','admin','',1,'CINDY & NICO DRIED FISH DEALER',0,0,'0',0,0,1),(77,'DFB','DRIED FISH BALUDNON',' ','DRIED FISH','0','','0','','0',1.25,'1KL',1,500,'2013-06-26 16:22:23','admin','',1,'CINDY & NICO DRIED FISH DEALER',0,0,'0',0,0,1),(79,'DFP','DRIED FISH PUSIT',' ','DRIED FISH','0','','0','','0',0.5,'1KL',1,700,'2013-06-26 16:22:58','admin','',1,'CINDY & NICO DRIED FISH DEALER',0,0,'0',0,0,1),(80,'DFK','DRIED FISH KARBALYAS',' ','DRIED FISH','0','','0','','0',0.8640000000000001,'1KL',1,230,'2013-06-26 16:22:43','admin','',1,'CINDY & NICO DRIED FISH DEALER',0,0,'0',0,0,1),(87,'DFM','DRIED FISH MANULSOG',' ','DRIED FISH','0','','0','','0',0,'1KL',1,230,'2013-06-26 16:22:50','admin','',1,'CINDY & NICO DRIED FISH DEALER',0,0,'0',0,0,1),(90,'RS','REFINED SUGAR',' ','SUGAR','0','','0','','0',-4.5,'250G',0.25,10.7,'2013-06-27 17:04:27','admin','',1,'NEW BIAN YEK COMMERCIAL',1,4000,'0',1,0,1),(93,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',0,'250G',1,8.65,'2013-07-12 17:39:58','null','',1,'NEW BIAN YEK COMMERCIAL',1,8.08,'0',1,0,12),(95,'SR5','SUNRICE 5KLS',' ','RICE','0','','0','','0',-2,'1KL',1,202.65,'2013-06-27 16:46:21','admin','',1,'JOEBON MARKETING',1,0,'0',0,0,1),(97,'SR','SUNRICE',' ','RICE','0','','0','','0',-11,'1KL',1,39.5,'2013-06-27 17:03:58','admin','',1,'JOEBON MARKETING',1,0,'0',1,0,1),(99,'BAL','BALIKATAN RICE',' ','RICE','0','','0','','0',2509,'1KL',1,38.45,'2013-07-12 17:42:33','null','',1,'BM CEREAL',1,0,'0',1,0,25),(101,'YDR','YELLOW DRAGON RICE',' ','RICE','0','','0','','0',-5,'1KL',1,191,'2013-06-19 17:48:29','admin','',1,'BM CEREAL',1,0,'0',1,0,1),(104,'GSR','GOLD STAR RICE',' ','RICE','0','','0','','0',0,'1KL',1,35.8,'2013-06-27 17:03:49','admin','',1,'BM CEREAL',0,3500,'0',1,0,1),(108,'MO','MONGO',' ','VEGETABLES','0','','0','','0',4.75,'1KL',0.5,60,'2013-06-27 10:51:06','admin','',1,'WINBEE MARKETING',1,0,'0',1,0,1),(123,'CM','CRAB MEAT',' ','FROZEN ','0','','0','','0',15,'1KL',1,517,'2013-06-27 17:03:06','admin','',1,'CHENNIES',1,0,'0',0,0,1),(124,'C','CREAMDORY',' ','FROZEN ','0','','0','','0',11,'1KL',1,155,'2013-06-26 16:12:05','admin','',1,'CHENNIES',1,0,'0',0,0,1),(125,'CRS','CRAB SHELL',' ','','0','','0','','0',500,'PC',1,1.9,'2013-06-17 14:56:59','admin','',1,'CHENNIES',1,0,'0',0,0,1),(127,'CH','CHICHARON',' ','','0','','0','','0',5,'PC',1,20,'2013-06-01 17:45:53','admin','',1,'JUDITH MAQUILING',1,0,NULL,0,0,1),(128,'JL','JM LONGANIZA',' ','FROZEN ','0','','0','','0',-11,'PC',1,24.25,'2013-06-19 14:25:22','admin','',1,'JUDITH MAQUILING',1,22,'0',0,0,1),(129,'JH','JM HAMONADA',' ','FROZEN ','0','','0','','0',-8,'PC',1,33,'2013-06-19 14:24:22','admin','',1,'JUDITH MAQUILING',1,30,'0',0,0,1),(132,'WB','WHITE BEANS ',' ','VEGETABLES','0','','0','','0',-0.25,'1KL',0.5,70,'2013-06-27 16:32:06','admin','',1,'WINBEE MARKETING',1,0,'0',1,0,1),(134,'G','GARLIC',' ','SPICES','0','','0','','0',-20.674,'1KL',1,85,'2013-06-29 14:49:15','admin','',1,'WINBEE MARKETING',0,0,'0',0,0,1),(135,'TANG','TANGKONG',' ','VEGETABLES','0','','0','','0',-4,'PC',1,5,'2013-06-19 15:02:13','admin','',0,'QUIAMCO FARM',1,4,'0',0,0,1),(136,'GR','GALAY RED',' ','VEGETABLES','0','','0','','0',0,'PC',1,5,'2013-06-19 14:23:27','admin','',0,'QUIAMCO FARM',1,4,'0',0,0,1),(137,'GG','GALAY GREEN',' ','VEGETABLES','0','','0','','0',-1,'PC',1,5,'2013-06-19 14:23:18','admin','',0,'QUIAMCO FARM',1,4,'0',0,0,1),(138,'LC','LUTTUCE CURLY',' ','VEGETABLES','0','','0','','0',0,'1KL',1,140,'2013-06-26 16:14:23','admin','',0,'QUIAMCO FARM',1,0,'0',0,0,1),(139,'LR','LETTUCE ROMAINE',' ','VEGETABLES','0','','0','','0',0,'1KL',1,140,'2013-06-26 16:14:49','admin','',0,'QUIAMCO FARM',1,0,'0',0,0,1),(140,'OK','OKRA',' ','VEGETABLES','0','','0','','0',0,'PC',1,6,'2013-07-12 17:41:09','null','',0,'QUIAMCO FARM',1,5,'0',0,0,12),(141,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',-26,'PC',1,10,'2013-06-28 08:59:03','admin','',0,'QUIAMCO FARM',1,100,'0',0,0,1),(147,'U','UPO',' ','VEGETABLES','0','','0','','0',0,'1KL',1,20,'2013-06-26 16:18:15','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(149,'GAR','GARBANZOS',' ','VEGETABLES','0','','0','','0',0,'1KL',1,40,'2013-06-26 16:15:54','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(150,'BB','BAGUIO BEANS',' ','VEGETABLES','0','','0','','0',-21,'1KL',1,30,'2013-06-26 16:16:14','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(151,'SE','SEQUA',' ','VEGETABLES','0','','0','','0',0,'1KL',1,20,'2013-06-26 16:16:31','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(152,'ST','STRING BEANS',' ','VEGETABLES','0','','0','','0',0,'1KL',1,10,'2013-06-26 16:16:53','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(153,'ALUG','ALUGBATI',' ','VEGETABLES','0','','0','','0',101,'1KL',1,5,'2013-07-12 17:38:55','null','',1,'QUIAMCO FARM',0,100,'0',0,0,11),(154,'LUY','LUY-A',' ','VEGETABLES','0','','0','','0',0,'1KL',1,40,'2013-06-26 16:17:17','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(155,'AT','ATSAL',' ','VEGETABLES','0','','0','','0',6,'1KL',1,100,'2013-07-12 17:34:33','null','',1,'QUIAMCO FARM',0,5,'0',0,0,51),(156,'BAN','BANANA',' ','FRUITS','0','','0','','0',-10,'PC',1,2.5,'2013-06-26 16:12:34','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(157,'S','SALT',' ','SALT','0','','0','','0',-4.5,'1KL',1,6,'2013-06-27 17:03:31','admin','',1,'NEW BIAN YEK COMMERCIAL',1,4.9,'0',1,0,1),(161,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',37,'PC',1,5,'2013-06-27 17:02:37','admin','',1,'QUIAMCO FARM',0,4.5,'0',1,0,1),(162,'SIL','SILAY',' ','DRIED FISH','0','','0','','0',-0.16199999999999998,'1KL',1,250,'2013-06-26 16:23:05','admin','',1,'CINDY & NICO DRIED FISH DEALER',0,0,'0',0,0,1),(164,'DF','DRAGON FRUIT',' ','FRUITS','0','','0','','0',0,'1KL',1,120,'2013-06-26 16:13:32','admin','',1,'QUIAMCO FARM',0,0,'0',0,0,1),(165,'POT','POTATO',' ','VEGETABLES','0','','0','','0',5.386,'1KL',1,60,'2013-06-26 16:17:47','admin','',1,'WINBEE MARKETING',0,0,'0',0,0,1),(167,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',340,'PC',0.25,25,'2013-06-27 14:28:32','admin','',1,'S&R MEMBERSHIP',1,0,'0',1,0,1),(168,'YDR5','YELLOW DRAGON RICE 5KLS',' ','RICE','0','','0','','0',-4,'PC',1,191,'2013-06-27 11:07:24','admin','',1,'BM CEREAL',1,0,'0',0,0,1),(169,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',-37.864999999999995,'KILO',1,195,'2013-06-26 10:51:31','admin','',1,'JUDITH MAQUILING',0,170,'JUDITH MAQUILING',0,0,1),(170,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',-11.546,'KILO',1,80,'2013-06-26 10:52:14','admin','',1,'JUDITH MAQUILING',0,60,'JUDITH MAQUILING',0,0,1),(172,'PPT','PORK PATA',' ','FRESH MEAT','0','','0','','0',0,'KILO',1,120,'2013-06-26 10:53:24','admin','',1,'JUDITH MAQUILING',0,100,'JUDITH MAQUILING',0,0,1),(173,'PSK','PORK SKINLESS',' ','FRESH MEAT','0','','0','','0',-5.5440000000000005,'KILO',1,185,'2013-06-26 10:54:08','admin','',1,'JUDITH MAQUILING',0,160,'JUDITH MAQUILING',0,0,1),(174,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',-6.281,'KILO',1,195,'2013-06-26 10:55:05','admin','',1,'JUDITH MAQUILING',0,170,'JUDITH MAQUILING',0,0,1),(175,'PL','PORK LIVER',' ','FRESH MEAT','0','','0','','0',0,'KILO',1,138,'2013-06-26 10:56:17','admin','',1,'JUDITH MAQUILING',0,120,'JUDITH MAQUILING',0,0,1),(176,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',-66.7969,'KILO',1,185,'2013-06-26 10:56:45','admin','',1,'JUDITH MAQUILING',0,160,'JUDITH MAQUILING',0,0,1),(177,'BG','BEEF GROUND',' ','FRESH MEAT','0','','0','','0',0,'KILO',1,207,'2013-06-26 10:57:33','admin','',1,'JUDITH MAQUILING',0,180,'JUDITH MAQUILING',0,0,1),(178,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',-12.958000000000002,'KILO',1,218,'2013-06-26 10:58:08','admin','',1,'JUDITH MAQUILING',0,190,'JUDITH MAQUILING',0,0,1),(179,'BP','BEEF PECHO',' ','FRESH MEAT','0','','0','','0',0,'KILO',1,138,'2013-06-26 10:58:34','admin','',1,'JUDITH MAQUILING',0,120,'JUDITH MAQUILING',0,0,1),(180,'BD','BEEF DILA',' ','FRESH MEAT','0','','0','','0',0,'KILO',1,150,'2013-06-26 10:59:17','admin','',1,'JUDITH MAQUILING',0,120,'JUDITH MAQUILING',0,0,1),(182,'CD','CHICKEN DRUMSTICK',' ','FRESH MEAT','0','','0','','0',0,'KILO',1,143,'2013-07-12 17:36:32','null','',1,'BOUNTY FRESH',0,0,'0',0,0,15),(183,'TP','PECHAY TAIWAN',' ','VEGETABLES','0','','0','','0',-1.17,'1KL',1,60,'2013-06-28 09:01:14','admin','',0,'QUIAMCO FARM',0,0,'0',0,0,1),(184,'4806518440019','SEA WORLD TEMPURA 500g',' ','FROZEN ','0','','0','','0',-3,'PC',1,72.75,'2013-06-27 15:06:14','admin','',1,'SEA WORLD ',1,57.5,'0',0,0,1),(185,'TP','PECHAY TAIWAN',' ','VEGETABLES','0','','0','','0',-1.17,'1KL',1,60,'2013-06-28 09:01:14','admin','',0,'QUIAMCO FARM',0,0,'0',0,0,1),(186,'PT','PORK TENDER',' ','FRESH MEAT','0','','0','','0',-2.48,'KILO',1,195,'2013-06-28 14:05:40','admin','',1,'JUDITH MAQUILING',0,170,'JUDITH MAQUILING',0,0,1),(188,'O','ONION',' ','SPICES','0','','0','','0',-20.656,'1KL',1,60,'2013-06-29 14:51:03','admin','',1,'WINBEE MARKETING',0,0,'WINBEE MARKETING',0,0,1),(189,'EL2','EGGS LARGE ',' ','EGGS','0','','0','','0',-12,'PC',1,5.3,'2013-06-29 14:54:01','admin','',1,'QUIAMCO FARM',1,4.7,'QUIAMCO FARM',1,0,1),(190,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',-1069,'PC',1,5.3,'2013-06-29 14:54:31','admin','',1,'QUIAMCO FARM',1,4.7,'QUIAMCO FARM',1,0,1),(191,'NMR5','NEW MOON RICE 5KLS',' ','RICE','0','','0','','0',-3,'PC',1,189,'2013-06-29 16:09:12','admin','',1,'BM CEREAL',1,0,'BM CEREAL',0,0,1),(193,'T','TOMATO',' ','VEGETABLES','0','','0','','0',0,'1KL',1,30,'2013-07-01 08:42:14','admin','',1,'QUIAMCO FARM',0,25,'QUIAMCO FARM',0,0,1),(194,'C','CALAMANSI 100\'S',' ','FRUITS','0','','0','','0',11,'PC',1,40,'2013-07-01 09:07:48','admin','',1,'QUIAMCO FARM',0,35,'QUIAMCO FARM',0,0,1),(195,'EP','EGGPLANT',' ','VEGETABLES','0','','0','','0',1,'1KL',1,30,'2013-07-01 09:19:41','admin','',1,'QUIAMCO FARM',0,0,'QUIAMCO FARM',0,0,1),(196,'P','PARSLEY',' ','VEGETABLES','0','','0','','0',-0.2,'KILO',1,170,'2013-07-02 10:41:19','admin','',0,'QUIAMCO FARM',0,150,'QUIAMCO FARM',0,0,1);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multi_pricing`
--

DROP TABLE IF EXISTS `multi_pricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_pricing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qty` double DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `invoice_qty` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multi_pricing`
--

LOCK TABLES `multi_pricing` WRITE;
/*!40000 ALTER TABLE `multi_pricing` DISABLE KEYS */;
/*!40000 ALTER TABLE `multi_pricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_inventory`
--

DROP TABLE IF EXISTS `new_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `new_inventory_no` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_inventory`
--

LOCK TABLES `new_inventory` WRITE;
/*!40000 ALTER TABLE `new_inventory` DISABLE KEYS */;
INSERT INTO `new_inventory` VALUES (2,NULL,'2013-06-28 11:40:20','NI-00000000001',0),(3,NULL,'2013-06-28 11:40:53','NI-00000000002',0),(4,NULL,'2013-06-28 11:41:33','NI-00000000003',0),(5,NULL,'2013-06-28 11:42:13','NI-00000000004',0),(6,NULL,'2013-06-28 11:42:24','NI-00000000005',0),(7,NULL,'2013-06-28 11:42:36','NI-00000000006',0),(8,NULL,'2013-06-28 11:42:42','NI-00000000007',0),(9,'admin','2013-06-28 11:49:14','NI-00000000008',0),(10,NULL,'2013-06-28 12:39:32','NI-00000000009',0),(11,'admin','2013-06-29 08:40:50','NI-00000000010',0),(12,'admin','2013-06-29 08:41:00','NI-00000000011',0),(13,'admin','2013-06-29 08:57:38','NI-00000000012',0),(14,'admin','2013-06-29 08:58:11','NI-00000000013',0),(15,'admin','2013-06-29 08:59:57','NI-00000000014',0),(16,'admin','2013-06-29 09:00:54','NI-00000000015',0),(17,'admin','2013-06-29 09:01:55','NI-00000000016',0),(18,'admin','2013-06-29 09:02:16','NI-00000000017',0),(19,'admin','2013-06-29 09:03:00','NI-00000000018',0),(20,'admin','2013-06-29 09:03:50','NI-00000000019',0),(21,'admin','2013-06-29 09:03:59','NI-00000000020',0),(22,'admin','2013-06-29 09:04:20','NI-00000000021',0),(23,'admin','2013-06-29 09:04:38','NI-00000000022',0),(24,'admin','2013-06-29 09:05:24','NI-00000000023',0),(25,'admin','2013-06-29 09:06:00','NI-00000000024',0),(26,'admin','2013-06-29 09:06:26','NI-00000000025',0),(27,'admin','2013-06-29 09:07:46','NI-00000000026',0),(28,'admin','2013-06-29 09:09:06','NI-00000000027',0),(29,'admin','2013-06-29 09:09:41','NI-00000000028',0),(30,'admin','2013-06-29 14:58:23','NI-00000000029',0),(31,'admin','2013-07-01 09:42:52','NI-00000000030',0),(32,'admin','2013-07-01 09:44:18','NI-00000000031',0),(33,'admin','2013-07-01 09:44:54','NI-00000000032',0),(34,'admin','2013-07-01 09:45:53','NI-00000000033',0),(35,'admin','2013-07-01 09:47:30','NI-00000000034',0),(36,'admin','2013-07-01 09:48:31','NI-00000000035',0),(37,'admin','2013-07-01 09:48:56','NI-00000000036',0),(38,'admin','2013-07-01 09:49:25','NI-00000000037',0),(39,'admin','2013-07-01 09:50:08','NI-00000000038',0),(40,'admin','2013-07-01 09:51:11','NI-00000000039',0),(41,'admin','2013-07-01 09:53:28','NI-00000000040',0),(42,'admin','2013-07-01 09:54:01','NI-00000000041',0),(43,'admin','2013-07-01 09:54:18','NI-00000000042',0),(44,'admin','2013-07-01 09:54:52','NI-00000000043',0),(45,'admin','2013-07-01 09:57:27','NI-00000000044',0),(46,'admin','2013-07-01 10:00:06','NI-00000000045',0),(47,'admin','2013-07-01 10:00:27','NI-00000000046',0),(48,'admin','2013-07-01 10:01:14','NI-00000000047',0),(49,'admin','2013-07-01 10:01:48','NI-00000000048',0),(50,'admin','2013-07-01 10:02:25','NI-00000000049',0),(51,'admin','2013-07-01 10:03:02','NI-00000000050',0),(52,'admin','2013-07-08 17:03:28','NI-00000000051',0),(53,'admin','2013-07-13 15:16:00','NI-00000000052',0);
/*!40000 ALTER TABLE `new_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_inventory_items`
--

DROP TABLE IF EXISTS `new_inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_inventory_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `new_inventory_no` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `barcode` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `previous_qty` double DEFAULT NULL,
  `new_qty` double DEFAULT NULL,
  `selling_price` double DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `conversion` double DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `classification` varchar(100) DEFAULT NULL,
  `classification_id` varchar(100) DEFAULT NULL,
  `sub_class` varchar(100) DEFAULT NULL,
  `sub_class_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_inventory_items`
--

LOCK TABLES `new_inventory_items` WRITE;
/*!40000 ALTER TABLE `new_inventory_items` DISABLE KEYS */;
INSERT INTO `new_inventory_items` VALUES (1,NULL,'2013-06-28 11:40:20','NI-00000000001','1KL','BAL','BALIKATAN RICE - 1KL',150,100,15000,'1KL',1,'RICE','0','','0','','0'),(2,NULL,'2013-06-28 11:40:53','NI-00000000002','1KL','BAL','BALIKATAN RICE - 1KL',0,200,0,'1KL',1,'RICE','0','','0','','0'),(3,NULL,'2013-06-28 11:41:33','NI-00000000003','1KL','BAL','BALIKATAN RICE - 1KL',0,200,0,'1KL',1,'RICE','0','','0','','0'),(4,NULL,'2013-06-28 11:42:13','NI-00000000004','1KL','BAL','BALIKATAN RICE - 1KL',200,0,0,'1KL',1,'RICE','0','','0','','0'),(5,NULL,'2013-06-28 11:42:24','NI-00000000005','2KLS','BAL','BALIKATAN RICE - 2KLS',0,2,0,'2KLS',2,'RICE','0','','0','','0'),(6,NULL,'2013-06-28 11:42:36','NI-00000000006','1KL','BAL','BALIKATAN RICE - 1KL',4,0,0,'1KL',1,'RICE','0','','0','','0'),(7,NULL,'2013-06-28 11:42:42','NI-00000000007','25KL','BAL','BALIKATAN RICE - 25KL',0,1,0,'25KL',25,'RICE','0','','0','','0'),(8,'admin','2013-06-28 11:49:14','NI-00000000008','1KL','ALUG','ALUGBATI - 1KL',-1,5,-5,'1KL',1,'VEGETABLES','0','','0','','0'),(9,NULL,'2013-06-28 12:39:32','NI-00000000009','1KL','AM','AMPALAYA - 1KL',0,1,0,'1KL',1,'VEGETABLES','0','','0','','0'),(10,'admin','2013-06-29 08:40:50','NI-00000000010','1KL','ALUG','ALUGBATI - 1KL',0,10,0,'1KL',1,'VEGETABLES','0','','0','','0'),(11,'admin','2013-06-29 08:41:00','NI-00000000011','1KL','ALUG','ALUGBATI - 1KL',10,9,90,'1KL',1,'VEGETABLES','0','','0','','0'),(12,'admin','2013-06-29 08:57:38','NI-00000000012','PC','CRS','CRAB SHELL - PC',0,500,0,'PC',1,'','0','','0','','0'),(13,'admin','2013-06-29 08:58:11','NI-00000000013','1KL','CM','CRAB MEAT - 1KL',0,15,0,'1KL',1,'FROZEN ','0','','0','','0'),(14,'admin','2013-06-29 08:59:57','NI-00000000014','2KLS','FF','FRENCH FRIES  - 2KLS',0,211,0,'2KLS',2,'FROZEN ','0','','0','','0'),(15,'admin','2013-06-29 09:00:54','NI-00000000015','PC','FB500','SEA WORLD FISH BALL 500G - PC',0,20,0,'PC',1,'FROZEN ','0','','0','','0'),(16,'admin','2013-06-29 09:01:55','NI-00000000016','1KL','DFP','DRIED FISH PUSIT - 1KL',0,0.5,0,'1KL',1,'DRIED FISH','0','','0','','0'),(17,'admin','2013-06-29 09:02:16','NI-00000000017','1KL','DFK','DRIED FISH KARBALYAS - 1KL',0,1,0,'1KL',1,'DRIED FISH','0','','0','','0'),(18,'admin','2013-06-29 09:03:00','NI-00000000018','1KL','DFB','DRIED FISH BALUDNON - 1KL',0,1.25,0,'1KL',1,'DRIED FISH','0','','0','','0'),(19,'admin','2013-06-29 09:03:50','NI-00000000019','500G','4806518440040','SEA WORLD SQUID BALL 500G - 500G',0,10,0,'500G',1,'FROZEN ','0','','0','','0'),(20,'admin','2013-06-29 09:03:59','NI-00000000020','500G','4806518440071','SEA WORLD SQUID ROLL 500G - 500G',0,20,0,'500G',1,'FROZEN ','0','','0','','0'),(21,'admin','2013-06-29 09:04:20','NI-00000000021','1KL','fp','FROZEN PEAS - 1KL',0,55,0,'1KL',1,'FROZEN ','0','','0','','0'),(22,'admin','2013-06-29 09:04:38','NI-00000000022','500G','fp','FROZEN PEAS - 500G',110,1,110,'500G',0.5,'FROZEN ','0','','0','','0'),(23,'admin','2013-06-29 09:05:24','NI-00000000023','250G','fp','FROZEN PEAS - 250G',2,5,10,'250G',0.25,'FROZEN ','0','','0','','0'),(24,'admin','2013-06-29 09:06:00','NI-00000000024','1KL','fp','FROZEN PEAS - 1KL',1.25,55,68.75,'1KL',1,'FROZEN ','0','','0','','0'),(25,'admin','2013-06-29 09:06:26','NI-00000000025','500G','fp','FROZEN PEAS - 500G',110,1,110,'500G',0.5,'FROZEN ','0','','0','','0'),(26,'admin','2013-06-29 09:07:46','NI-00000000026','250G','fp','FROZEN PEAS - 250G',2,5,10,'250G',0.25,'FROZEN ','0','','0','','0'),(27,'admin','2013-06-29 09:09:06','NI-00000000027','500G','FF','FRENCH FRIES  - 500G',844,0,0,'500G',0.5,'FROZEN ','0','','0','','0'),(28,'admin','2013-06-29 09:09:41','NI-00000000028','2KLS','FF','FRENCH FRIES  - 2KLS',0,211,0,'2KLS',2,'FROZEN ','0','','0','','0'),(29,'admin','2013-06-29 14:58:23','NI-00000000029','2KLS','FF','FRENCH FRIES  - 2KLS',192.75,195,37586.25,'2KLS',2,'FROZEN ','0','','0','','0'),(30,'admin','2013-07-01 09:42:52','NI-00000000030','1KL','ALUG','ALUGBATI - 1KL',9,0,0,'1KL',1,'VEGETABLES','0','','0','','0'),(31,'admin','2013-07-01 09:44:18','NI-00000000031','1KL','CS','CENTRIFUGALSUGAR - 1KL',-1.5,14,-21,'1KL',1,'SUGAR','0','','0','','0'),(32,'admin','2013-07-01 09:44:54','NI-00000000032','1KL','C','CREAMDORY - 1KL',-0.5,11,-5.5,'1KL',1,'FROZEN ','0','','0','','0'),(33,'admin','2013-07-01 09:45:53','NI-00000000033','PC','EC','EGGS CRACKED - PC',-28,12,-336,'PC',1,'EGGS','0','','0','','0'),(34,'admin','2013-07-01 09:47:30','NI-00000000034','2KLS','FF','FRENCH FRIES  - 2KLS',195,193,37635,'2KLS',2,'FROZEN ','0','','0','','0'),(35,'admin','2013-07-01 09:48:31','NI-00000000035','1KL','BAL','BALIKATAN RICE - 1KL',-1,5,-5,'1KL',1,'RICE','0','','0','','0'),(36,'admin','2013-07-01 09:48:56','NI-00000000036','PC','C','CALAMANSI 100\'S - PC',11,0,0,'PC',1,'FRUITS','0','','0','','0'),(37,'admin','2013-07-01 09:49:25','NI-00000000037','PC','CH','CHICHARON - PC',0,6,0,'PC',1,'','0','','0','','0'),(38,'admin','2013-07-01 09:50:08','NI-00000000038','1KL','C','CREAMDORY - 1KL',0,11,0,'1KL',1,'FROZEN ','0','','0','','0'),(39,'admin','2013-07-01 09:51:11','NI-00000000039','PC','EC','EGGS CRACKED - PC',7,12,84,'PC',1,'EGGS','0','','0','','0'),(40,'admin','2013-07-01 09:53:28','NI-00000000040','PC','EM','EGGS MEDIUM - PC',-70,59,-4130,'PC',1,'EGGS','0','','0','','0'),(41,'admin','2013-07-01 09:54:01','NI-00000000041','PC','ES','EGGS SMALL - PC',0,106,0,'PC',1,'EGGS','0','','0','','0'),(42,'admin','2013-07-01 09:54:18','NI-00000000042','PC','EP','EGGS PEEWEE - PC',-0.51,1,-0.51,'PC',1,'EGGS','0','','0','','0'),(43,'admin','2013-07-01 09:54:52','NI-00000000043','PC','EXL','EGGS X-LARGE - PC',-78,60,-4680,'PC',1,'EGGS','0','','0','','0'),(44,'admin','2013-07-01 09:57:27','NI-00000000044','1KL','4800282000080','MIXED VEGETABLES - 1KL',0,57,0,'1KL',1,'FROZEN ','0','','0','','0'),(45,'admin','2013-07-01 10:00:06','NI-00000000045','1KL','MO','MONGO - 1KL',-3,10,-30,'1KL',0.5,'VEGETABLES','0','','0','','0'),(46,'admin','2013-07-01 10:00:27','NI-00000000046','1KL','MO','MONGO - 1KL',5,10,50,'1KL',0.5,'VEGETABLES','0','','0','','0'),(47,'admin','2013-07-01 10:01:14','NI-00000000047','1KL','MO','MONGO - 1KL',5,10,50,'1KL',0.5,'VEGETABLES','0','','0','','0'),(48,'admin','2013-07-01 10:01:48','NI-00000000048','1KL','MO','MONGO - 1KL',5,10,50,'1KL',0.5,'VEGETABLES','0','','0','','0'),(49,'admin','2013-07-01 10:02:25','NI-00000000049','1KL','MO','MONGO - 1KL',5,10,50,'1KL',0.5,'VEGETABLES','0','','0','','0'),(50,'admin','2013-07-01 10:03:02','NI-00000000050','1KL','TP','PECHAY TAIWAN - 1KL',-2.72,0,0,'1KL',1,'VEGETABLES','0','','0','','0'),(51,'admin','2013-07-08 17:03:28','NI-00000000051','1KL','BAL','BALIKATAN RICE - 1KL',3,0,0,'1KL',1,'RICE','0','','0','','0'),(52,'admin','2013-07-13 15:16:00','NI-00000000052','1KL','ALUG','ALUGBATI - 1KL',0,100,0,'1KL',1,'VEGETABLES','0','','0','','0');
/*!40000 ALTER TABLE `new_inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_no` varchar(100) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `session_no` varchar(500) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `supplier` varchar(500) DEFAULT NULL,
  `supllier_id` varchar(500) DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  `barcode` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `qty` double DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `category` varchar(500) DEFAULT NULL,
  `category_id` varchar(500) DEFAULT NULL,
  `classification` varchar(500) DEFAULT NULL,
  `classification_id` varchar(500) DEFAULT NULL,
  `sub_class` varchar(500) DEFAULT NULL,
  `sub_class_id` varchar(500) DEFAULT NULL,
  `conversion` int(11) DEFAULT NULL,
  `unit` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
INSERT INTO `purchase_order_items` VALUES (1,'PO-00000000002',NULL,NULL,'2013-07-16 14:27:03','BM CEREAL','0','','BAL','BALIKATAN RICE - 2KLS',1,0,'RICE','0','','0','','0',2,'2KLS'),(2,'PO-00000000002',NULL,NULL,'2013-07-16 14:27:03','JUDITH MAQUILING','JUDITH MAQUILING','','BD','BEEF DILA - KILO',2,120,'FRESH MEAT','0','','0','','0',1,'KILO'),(3,'PO-00000000002',NULL,NULL,'2013-07-16 14:27:03','JUDITH MAQUILING','JUDITH MAQUILING','','BG','BEEF GROUND - KILO',100,180,'FRESH MEAT','0','','0','','0',1,'KILO'),(4,'PO-00000000003','admin','','2013-07-16 14:28:00','JUDITH MAQUILING','JUDITH MAQUILING','','BT','BEEF TENDERLOIN - KILO',3,190,'FRESH MEAT','0','','0','','0',1,'KILO'),(5,'PO-00000000003','admin','','2013-07-16 14:28:00','JUDITH MAQUILING','JUDITH MAQUILING','','BP','BEEF PECHO - KILO',2,120,'FRESH MEAT','0','','0','','0',1,'KILO'),(6,'PO-00000000004','admin','','2013-07-16 14:30:18','QUIAMCO FARM','0','','AT','ATSAL - 1KL',2,5,'VEGETABLES','0','','0','','0',1,'1KL'),(7,'PO-00000000004','admin','','2013-07-16 14:30:18','QUIAMCO FARM','0','','ALUG','ALUGBATI - 1KL',2,100,'VEGETABLES','0','','0','','0',1,'1KL'),(8,'PO-00000000004','admin','','2013-07-16 14:30:18','JUDITH MAQUILING','JUDITH MAQUILING','','BT','BEEF TENDERLOIN - KILO',2,190,'FRESH MEAT','0','','0','','0',1,'KILO');
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_no` varchar(100) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `session_no` varchar(500) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
INSERT INTO `purchase_orders` VALUES (1,'PO-00000000002',NULL,NULL,'2013-07-16 14:27:03',''),(2,'PO-00000000003','admin','','2013-07-16 14:28:00',''),(3,'PO-00000000004','admin','','2013-07-16 14:30:18','');
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt_items`
--

DROP TABLE IF EXISTS `receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(500) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `session_no` varchar(500) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `supplier` varchar(500) DEFAULT NULL,
  `supllier_id` varchar(500) DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  `barcode` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `qty` double DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `classification` varchar(100) DEFAULT NULL,
  `classification_id` varchar(100) DEFAULT NULL,
  `sub_class` varchar(100) DEFAULT NULL,
  `sub_class_id` varchar(100) DEFAULT NULL,
  `conversion` double DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `date_delivered` date DEFAULT NULL,
  `date_received` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt_items`
--

LOCK TABLES `receipt_items` WRITE;
/*!40000 ALTER TABLE `receipt_items` DISABLE KEYS */;
INSERT INTO `receipt_items` VALUES (1,'RN-00000000002',NULL,NULL,'2013-06-25 19:56:12','','0','','ALUG','ALUGBATI - PC',50,100,'VEGETABLES','0','','0','','0',1,'PC','2013-06-25','2013-06-25'),(2,'RN-00000000002',NULL,NULL,'2013-06-25 19:56:12','','0','','GSR1','GOLD STAR RICE - 1KL',100,3500,'RICE','0','','0','','0',1,'1KL','2013-06-25','2013-06-25'),(3,'RN-00000000002',NULL,NULL,'2013-06-25 19:56:12','','0','','PN','PECHAY NATIVE 250G - PC',10,100,'VEGETABLES','0','','0','','0',1,'PC','2013-06-25','2013-06-25'),(4,'RN-00000000002',NULL,NULL,'2013-06-25 19:56:12','','0','','RS250','REFINED SUGAR - 1KL',10,4000,'SUGAR','0','','0','','0',1,'1KL','2013-06-25','2013-06-25'),(5,'RN-00000000003','admin','','2013-06-25 20:24:54','BM CEREAL','0','','BAL1','BALIKATAN RICE - 1KL',50,1000,'RICE','0','','0','','0',1,'1KL','2013-06-25','2013-06-25'),(6,'RN-00000000004','admin','','2013-06-25 20:27:05','BM CEREAL','0','','BAL1','BALIKATAN RICE - 1KL',1,0,'RICE','0','','0','','0',1,'1KL','2013-06-25','2013-06-25'),(7,'RN-00000000005','admin','','2013-06-27 10:50:31','WINBEE MARKETING','0','','MO','MONGO - SACK',1,0,'VEGETABLES','0','','0','','0',25,'SACK','2013-06-27','2013-06-27'),(8,'RN-00000000006','admin','','2013-07-01 10:06:46','WINBEE MARKETING','0','','POT','POTATO - 1KL',8.71,0,'VEGETABLES','0','','0','','0',1,'1KL','2013-07-01','2013-07-01'),(9,'RN-00000000007','admin','','2013-07-01 10:07:37','WINBEE MARKETING','0','','O','ONION - 1KL',8.7,0,'SPICES','0','','0','','0',1,'1KL','2013-07-01','2013-07-01'),(10,'RN-00000000008','admin','','2013-07-01 10:14:55','JUDITH MAQUILING','0','','PG','PORK GROUND - KILO',7.57,170,'FRESH MEAT','0','','0','','0',1,'KILO','2013-07-01','2013-07-01'),(11,'RN-00000000009','admin','','2013-07-01 10:18:50','BOUNTY FRESH','0','','CB','CHICKEN BREAST - KILO',19.68,0,'FRESH MEAT','0','','0','','0',1,'KILO','2013-07-01','2013-07-01'),(12,'RN-00000000010','admin','','2013-07-01 10:19:15','BOUNTY FRESH','0','','CD','CHICKEN DRUMSTICK - KILO',5.94,0,'FRESH MEAT','0','','0','','0',1,'KILO','2013-07-01','2013-07-01'),(13,'RN-00000000011','admin','','2013-07-01 10:19:35','BOUNTY FRESH','0','','CD','CHICKEN DRUMSTICK - KILO',5.94,0,'FRESH MEAT','0','','0','','0',1,'KILO','2013-07-01','2013-07-01'),(14,'RN-00000000012','admin','','2013-07-08 15:10:17','QUIAMCO FARM','0','','AT','ATSAL - 1KL',50,5,'VEGETABLES','0','','0','','0',1,'1KL','2013-07-08','2013-07-08'),(15,'RN-00000000013','admin','','2013-07-08 17:04:05','BM CEREAL','0','','BAL','BALIKATAN RICE - 1KL',25,0,'RICE','0','','0','','0',1,'1KL','2013-07-08','2013-07-08'),(16,'RN-00000000015','admin','','2013-07-16 11:25:50','QUIAMCO FARM','0','','AT','ATSAL - 1KL',5,5,'VEGETABLES','0','','0','','0',1,'1KL','2013-07-15',NULL),(17,'RN-00000000016','admin','','2013-07-16 11:28:16','QUIAMCO FARM','0','','ALUG','ALUGBATI - 1KL',2,100,'VEGETABLES','0','','0','','0',1,'1KL','2013-07-15',NULL),(18,'RN-00000000016','admin','','2013-07-16 11:28:16','QUIAMCO FARM','0','','AT','ATSAL - 1KL',2,5,'VEGETABLES','0','','0','','0',1,'1KL','2013-07-15',NULL),(19,'RN-00000000017','admin','','2013-09-02 14:16:13','BM CEREAL','0','','BAL','BALIKATAN RICE - 25KL',100,0,'RICE','0','','0','','0',25,'25KL','2013-09-02',NULL),(20,'RN-00000000018','admin','','2014-01-02 13:19:35','QUIAMCO FARM','0','','ALUG','ALUGBATI - 1KL',10,100,'VEGETABLES','0','','0','','0',1,'1KL','2014-01-02',NULL),(21,'RN-00000000018','admin','','2014-01-02 13:19:35','BM CEREAL','0','','BAL','BALIKATAN RICE - 1KL',10,0,'RICE','0','','0','','0',1,'1KL','2014-01-02',NULL);
/*!40000 ALTER TABLE `receipt_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `session_no` varchar(100) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `supllier_id` varchar(100) DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `date_delivered` date DEFAULT NULL,
  `date_received` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (1,'RN-00000000002',NULL,NULL,'2013-06-25 19:56:12','','0','','2013-06-25','2013-06-25'),(2,'RN-00000000003','admin','','2013-06-25 20:24:54','','0','','2013-06-25','2013-06-25'),(3,'RN-00000000004','admin','','2013-06-25 20:27:05','','0','','2013-06-25','2013-06-25'),(4,'RN-00000000005','admin','','2013-06-27 10:50:31','','0','','2013-06-27','2013-06-27'),(5,'RN-00000000006','admin','','2013-07-01 10:06:46','','0','','2013-07-01','2013-07-01'),(6,'RN-00000000007','admin','','2013-07-01 10:07:37','','0','','2013-07-01','2013-07-01'),(7,'RN-00000000008','admin','','2013-07-01 10:14:55','','0','','2013-07-01','2013-07-01'),(8,'RN-00000000009','admin','','2013-07-01 10:18:50','','0','','2013-07-01','2013-07-01'),(9,'RN-00000000010','admin','','2013-07-01 10:19:15','','0','','2013-07-01','2013-07-01'),(10,'RN-00000000011','admin','','2013-07-01 10:19:35','','0','','2013-07-01','2013-07-01'),(11,'RN-00000000012','admin','','2013-07-08 15:10:17','','0','','2013-07-08','2013-07-08'),(12,'RN-00000000013','admin','','2013-07-08 17:04:05','','0','','2013-07-08','2013-07-08'),(13,'RN-00000000014','admin','','2013-07-08 17:04:57','','0','','2013-07-08','2013-07-08'),(14,'RN-00000000015','admin','','2013-07-16 11:25:50','','0','','2013-07-15','2013-07-16'),(15,'RN-00000000016','admin','','2013-07-16 11:28:16','','0','','2013-07-15','2013-07-16'),(16,'RN-00000000017','admin','','2013-09-02 14:16:13','','0','','2013-09-02','2013-09-02'),(17,'RN-00000000018','admin','','2014-01-02 13:19:35','','0','','2014-01-02','2014-01-02');
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_no` varchar(100) DEFAULT NULL,
  `date_added` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `session_no` varchar(100) DEFAULT NULL,
  `gross_amount` double DEFAULT NULL,
  `amount_paid` double DEFAULT NULL,
  `amount_due` double DEFAULT NULL,
  `discount_name` varchar(100) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discount_amount` double DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `check_bank` varchar(100) DEFAULT NULL,
  `check_no` varchar(100) DEFAULT NULL,
  `check_amount` double DEFAULT NULL,
  `discount_customer_name` varchar(100) DEFAULT NULL,
  `discount_customer_id` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `or_no` varchar(100) DEFAULT NULL,
  `check_holder` varchar(100) DEFAULT NULL,
  `services` varchar(100) DEFAULT NULL,
  `service_amount` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (117,'0000000000000001','2013-06-28 10:48:56','lily','',646.03,700.05,646.03,'NO DISCOUNT',0,0,'FLIMAN GRILL','','',0,'','',0,'','0000000000000001','',0),(118,'0000000000000001','2013-06-28 10:51:09','lily','',176.73,200,176.73,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(119,'0000000000000001','2013-06-28 10:52:49','lily','',204.36,220,204.36,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(120,'0000000000000001','2013-06-28 10:55:22','lily','',118.5,500,118.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(121,'0000000000000001','2013-06-28 10:56:29','lily','',39.5,50,39.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(122,'0000000000000001','2013-06-28 11:15:50','lily','',1219.66,1500,1219.66,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(123,'0000000000000001','2013-06-28 11:29:31','lily','',100.3,100.3,100.3,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(124,'0000000000000001','2013-06-28 11:30:25','lily','',83.5,100.5,83.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(125,'0000000000000001','2013-06-28 11:35:51','lily','',159.85,500,159.85,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(126,'0000000000000001','2013-06-28 11:49:21','lily','',1200,1200,1200,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(127,'0000000000000001','2013-06-28 11:49:47','lily','',17.2,17.2,17.2,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(128,'0000000000000001','2013-06-28 11:50:25','lily','',173.9,173.9,173.9,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(129,'0000000000000001','2013-06-28 11:50:55','lily','',27.3,27.3,27.3,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(130,'0000000000000001','2013-06-28 11:51:31','lily','',60,60,60,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(131,'0000000000000001','2013-06-28 11:52:04','lily','',94.9,95,94.9,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(132,'0000000000000001','2013-06-28 11:52:26','lily','',17.2,17.2,17.2,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(133,'0000000000000001','2013-06-28 11:54:04','lily','',136.16,137,136.16,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(134,'0000000000000001','2013-06-28 11:56:09','lily','',2562.57,2600,2562.57,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(135,'0000000000000001','2013-06-28 11:56:32','lily','',400,400,400,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(136,'0000000000000001','2013-06-28 11:58:13','lily','',212.2,220,212.2,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(137,'0000000000000001','2013-06-28 12:00:57','lily','',1000,1000,1000,'NO DISCOUNT',0,0,'SCOOBYS','','',0,'','',0,'','0000000000000001','',0),(138,'0000000000000001','2013-06-28 14:09:53','lily','',50,100,50,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(139,'0000000000000001','2013-06-28 14:12:08','lily','',177.63,178,177.63,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(140,'0000000000000001','2013-06-28 14:13:35','lily','',121.2,125,121.2,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(141,'0000000000000001','2013-06-28 14:16:26','lily','',739.05,740,739.05,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(142,'0000000000000001','2013-06-28 14:17:12','lily','',190.92,191,190.92,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(143,'0000000000000001','2013-06-28 14:18:13','lily','',150,150,150,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(144,'0000000000000001','2013-06-28 14:19:01','lily','',280,290,280,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(145,'0000000000000001','2013-06-28 14:21:26','lily','',148.4,150,148.4,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(146,'0000000000000001','2013-06-28 14:22:04','lily','',997.6,1000,997.6,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(147,'0000000000000001','2013-06-28 14:22:54','lily','',107.3,108,107.3,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(148,'0000000000000001','2013-06-28 14:25:49','lily','',6.79,8,6.79,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(149,'0000000000000001','2013-06-28 14:26:33','lily','',38.45,40,38.45,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(150,'0000000000000001','2013-06-28 14:27:17','lily','',214.23,215,214.23,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(151,'0000000000000001','2013-06-28 14:27:53','lily','',26.5,30,26.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(152,'0000000000000001','2013-06-29 08:24:36','lily','',15,15,15,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(153,'0000000000000001','2013-06-29 08:33:07','lily','',38.45,50,38.45,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(154,'0000000000000001','2013-06-29 08:38:37','lily','',355.2,360.2,355.2,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(155,'0000000000000001','2013-06-29 08:42:30','lily','',31.7,100,31.7,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(156,'0000000000000001','2013-06-29 08:52:14','lily','',309.98,510,309.98,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(157,'0000000000000001','2013-06-29 08:55:21','lily','',1393.94,1500,1393.94,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(158,'0000000000000001','2013-06-29 08:56:58','lily','',187.42,1000,187.42,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(159,'0000000000000001','2013-06-29 08:57:56','lily','',10,10,10,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(160,'0000000000000001','2013-06-29 09:00:10','lily','',725.12,1000,725.12,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(161,'0000000000000001','2013-06-29 09:03:51','lily','',450,450,450,'NO DISCOUNT',0,0,'ubp','','',0,'','',0,'','0000000000000001','',0),(162,'0000000000000001','2013-06-29 09:10:19','lily','',1500,1500,1500,'NO DISCOUNT',0,0,'FOOD TOWN','','',0,'','',0,'','0000000000000001','',0),(163,'0000000000000001','2013-06-29 09:24:31','lily','',239.49,250,239.49,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(164,'0000000000000001','2013-06-29 09:28:35','lily','',356.31,1000,356.31,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(165,'0000000000000001','2013-06-29 09:33:37','lily','',442.49,500,442.49,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(166,'0000000000000001','2013-06-29 09:36:21','lily','',216.83,220,216.83,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(167,'0000000000000001','2013-06-29 09:46:07','lily','',72.15,100,72.15,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(168,'0000000000000001','2013-06-29 10:06:56','lily','',556.48,1070,556.48,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(169,'0000000000000001','2013-06-29 10:16:16','lily','',259.9,260,259.9,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(170,'0000000000000001','2013-06-29 10:19:49','lily','',4.76,5,4.76,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(171,'0000000000000001','2013-06-29 10:31:28','lily','',122.62,200,122.62,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(172,'0000000000000001','2013-06-29 10:32:17','lily','',82.52,100,82.52,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(173,'0000000000000001','2013-06-29 10:32:46','lily','',10,20,10,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(174,'0000000000000001','2013-06-29 10:34:39','lily','',1505.79,2000,1505.79,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(175,'0000000000000001','2013-06-29 10:39:31','lily','',256.89,500,256.89,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(176,'0000000000000001','2013-06-29 10:44:01','lily','',87.4,100,87.4,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(177,'0000000000000001','2013-06-29 10:51:35','lily','',1588.2,1588.25,1588.2,'NO DISCOUNT',0,0,'CANGS','','',0,'','',0,'','0000000000000001','',0),(178,'0000000000000001','2013-06-29 10:54:02','lily','',2173.28,2500,2173.28,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(179,'0000000000000001','2013-06-29 11:05:12','lily','',800,800,800,'NO DISCOUNT',0,0,'FLIMAN GRILL','','',0,'','',0,'','0000000000000001','',0),(180,'0000000000000001','2013-06-29 11:10:01','lily','',7270,7270,7270,'NO DISCOUNT',0,0,'','LAND BANK','0125206',7270,'','',0,'HOY LUGAW','0000000000000001','',0),(181,'0000000000000001','2013-06-29 11:13:25','lily','',290.9,290.9,290.9,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(182,'0000000000000001','2013-06-29 11:14:30','lily','',382,382,382,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(183,'0000000000000001','2013-06-29 11:15:43','lily','',130.08,130.1,130.08,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(184,'0000000000000001','2013-06-29 11:31:48','lily','',730,730,730,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(185,'0000000000000001','2013-06-29 11:38:55','lily','',33,40,33,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(186,'0000000000000001','2013-06-29 11:48:55','lily','',420,420,420,'NO DISCOUNT',0,0,'meliton gabas','','',0,'','',0,'','0000000000000001','',0),(187,'0000000000000001','2013-06-29 11:50:53','lily','',181.17,201.2,181.17,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(188,'0000000000000001','2013-06-29 14:01:29','lily','',147.06,150,147.06,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(189,'0000000000000001','2013-06-29 14:03:36','lily','',1000,1000,1000,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(190,'0000000000000001','2013-06-29 14:17:24','lily','',65,70,65,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(191,'0000000000000001','2013-06-29 14:19:19','lily','',150,200,150,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(192,'0000000000000001','2013-06-29 14:41:41','lily','',300,300,300,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(193,'0000000000000001','2013-06-29 14:48:48','lily','',145.5,150,145.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(194,'0000000000000001','2013-06-29 14:50:12','lily','',389.1,1000,389.1,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(195,'0000000000000001','2013-06-29 14:50:59','lily','',100,100,100,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(196,'0000000000000001','2013-06-29 14:52:39','lily','',190.6,500.6,190.6,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(197,'0000000000000001','2013-06-29 14:59:04','lily','',40.44,50.45,40.44,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(198,'0000000000000001','2013-06-29 15:01:20','lily','',1000,1000,1000,'NO DISCOUNT',0,0,'scoobys','','',0,'','',0,'','0000000000000001','',0),(199,'0000000000000001','2013-06-29 15:11:31','lily','',830.48,1000,830.48,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(200,'0000000000000001','2013-06-29 15:25:44','lily','',60,500,60,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(201,'0000000000000001','2013-06-29 15:58:39','admin','',400,1000,400,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(202,'0000000000000001','2013-06-29 16:01:09','admin','',95.2,100,95.2,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(203,'0000000000000001','2013-06-29 16:02:24','admin','',450,500,450,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(204,'0000000000000001','2013-06-29 16:12:16','lily','',130,128.84,130,'WITHOLDING TAX',0,1.16,'','','',0,'COCO GRANDE','',0,'','0000000000000001','',0),(205,'0000000000000001','2013-06-29 16:14:58','lily','',390,500,390,'WITHOLDING TAX',0,3.48,'','','',0,'APO ISLAND','',0,'','0000000000000001','',0),(206,'0000000000000001','2013-06-29 16:46:33','lily','',349.25,1000,349.25,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(207,'0000000000000001','2013-06-29 17:04:39','lily','',308.61,0,308.61,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(208,'0000000000000001','2013-06-29 17:08:03','lily','',544.42,550,544.42,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(209,'0000000000000001','2013-06-29 17:10:03','lily','',49.95,0,49.95,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(210,'0000000000000001','2013-06-29 17:15:26','lily','',378,1000,378,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(211,'0000000000000001','2013-06-29 17:17:07','lily','',191.84,500,191.84,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(212,'0000000000000001','2013-06-29 17:19:34','lily','',341,341,341,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(213,'0000000000000001','2013-06-29 17:21:17','lily','',342.88,500,342.88,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(214,'0000000000000001','2013-06-29 17:26:10','lily','',430.85,1001,430.85,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(215,'0000000000000001','2013-06-29 17:27:59','lily','',280,280,280,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(216,'0000000000000001','2013-06-29 17:30:14','lily','',531.32,531.35,531.32,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(217,'0000000000000001','2013-06-29 17:31:25','lily','',48.47,50,48.47,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(218,'0000000000000001','2013-06-29 17:33:41','lily','',51.4,51.4,51.4,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(219,'0000000000000001','2013-06-29 17:38:55','lily','',506.65,1000,506.65,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(220,'0000000000000001','2013-06-29 17:44:41','lily','',150,150,150,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(221,'0000000000000001','2013-06-29 17:53:28','lily','',450,450,450,'NO DISCOUNT',0,0,'kamalig','','',0,'','',0,'','0000000000000001','',0),(222,'0000000000000001','2013-06-29 18:01:07','lily','',135.36,0,135.36,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(223,'0000000000000001','2013-06-29 18:06:06','lily','',66.72,100,66.72,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(224,'0000000000000001','2013-07-01 08:36:20','lily','',254.13,254.15,254.13,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(225,'0000000000000001','2013-07-01 08:37:40','lily','',340,340,340,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(226,'0000000000000001','2013-07-01 08:39:35','lily','',201.58,201.6,201.58,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(227,'0000000000000001','2013-07-01 08:42:57','lily','',395.57,396,395.57,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(228,'0000000000000001','2013-07-01 08:44:34','lily','',560,600,560,'NO DISCOUNT',0,0,'cadiz','','',0,'','',0,'','0000000000000001','',0),(229,'0000000000000001','2013-07-01 08:52:09','lily','',1009.66,1009.7,1009.66,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(230,'0000000000000001','2013-07-01 08:54:29','lily','',213.04,213.05,213.04,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(231,'0000000000000001','2013-07-01 08:59:23','lily','',869.14,870,869.14,'NO DISCOUNT',0,0,'holy cross','','',0,'','',0,'','0000000000000001','',0),(232,'0000000000000001','2013-07-01 09:10:41','lily','',97.5,100,97.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(233,'0000000000000001','2013-07-01 09:29:20','lily','',1281.68,1282,1281.68,'NO DISCOUNT',0,0,'ERWIN QUIAMCO','','',0,'','',0,'','0000000000000001','',0),(234,'0000000000000001','2013-07-01 09:31:03','lily','',91.02,100,91.02,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(235,'0000000000000001','2013-07-01 09:33:44','lily','',74.13,200,74.13,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(236,'0000000000000001','2013-07-01 09:34:29','lily','',20,20,20,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(237,'0000000000000001','2013-07-01 09:40:43','lily','',140,140,140,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(238,'0000000000000001','2013-07-01 09:43:01','lily','',700,700,700,'NO DISCOUNT',0,0,'archer','','',0,'','',0,'','0000000000000001','',0),(239,'0000000000000001','2013-07-01 09:44:22','lily','',49.92,50,49.92,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(240,'0000000000000001','2013-07-01 09:53:47','lily','',215.38,250,215.38,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(241,'0000000000000001','2013-07-01 09:56:43','lily','',177.45,200,177.45,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(242,'0000000000000001','2013-07-01 10:06:52','lily','',148.95,200,148.95,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(243,'0000000000000001','2013-07-01 10:09:59','lily','',171.99,200,171.99,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(244,'0000000000000001','2013-07-01 10:25:49','lily','',198.12,500,198.12,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(245,'0000000000000001','2013-07-01 10:58:04','lily','',20,20,20,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(246,'0000000000000001','2013-07-01 11:56:29','lily','',926.64,1000,926.64,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(247,'0000000000000001','2013-07-01 14:00:56','lily','',25.13,50,25.13,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(248,'0000000000000001','2013-07-01 14:12:03','lily','',355.1,500,355.1,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(249,'0000000000000001','2013-07-01 14:14:49','lily','',600,600,600,'NO DISCOUNT',0,0,'SCOOBYS','','',0,'','',0,'','0000000000000001','',0),(250,'0000000000000001','2013-07-01 14:43:20','lily','',81.5,1000,81.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(251,'0000000000000001','2013-07-01 15:24:34','lily','',132.99,150,132.99,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(252,'0000000000000001','2013-07-01 15:27:22','lily','',101.79,1002,101.79,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(253,'0000000000000001','2013-07-01 15:29:48','lily','',67.71,70,67.71,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(254,'0000000000000001','2013-07-01 15:31:02','lily','',230,500,230,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(255,'0000000000000001','2013-07-01 15:35:05','lily','',1273,2000,1273,'NO DISCOUNT',0,0,'DON BOSCO','','',0,'','',0,'','0000000000000001','',0),(256,'0000000000000001','2013-07-01 15:38:21','lily','',560,560,560,'NO DISCOUNT',0,0,'CHIN LOONG','','',0,'','',0,'','0000000000000001','',0),(257,'0000000000000001','2013-07-01 15:38:41','lily','',140,0,140,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(258,'0000000000000001','2013-07-01 15:41:30','lily','',196.63,1000.75,196.63,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(259,'0000000000000001','2013-07-01 16:01:10','lily','',99.45,100,99.45,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(260,'0000000000000001','2013-07-01 16:33:22','lily','',150,150,150,'NO DISCOUNT',0,0,'F NACUA','','',0,'','',0,'','0000000000000001','',0),(261,'0000000000000001','2013-07-01 16:35:37','lily','',214,1000,214,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(262,'0000000000000001','2013-07-01 16:52:35','lily','',300,300,300,'NO DISCOUNT',0,0,'KYOSKO','','',0,'','',0,'','0000000000000001','',0),(263,'0000000000000001','2013-07-01 17:00:17','lily','',75.86,100,75.86,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(264,'0000000000000001','2013-07-01 17:01:19','lily','',300,300,300,'NO DISCOUNT',0,0,'ubp','','',0,'','',0,'','0000000000000001','',0),(265,'0000000000000001','2013-07-01 17:02:44','lily','',142.12,200,142.12,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(266,'0000000000000001','2013-07-01 17:15:32','lily','',471.26,500,471.26,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(267,'0000000000000001','2013-07-01 17:17:31','lily','',122.43,500,122.43,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(268,'0000000000000001','2013-07-01 17:20:44','lily','',112.75,500,112.75,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(269,'0000000000000001','2013-07-01 17:22:03','lily','',115.44,500,115.44,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(270,'0000000000000001','2013-07-01 17:23:19','lily','',400,1000,400,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(271,'0000000000000001','2013-07-01 17:24:18','lily','',296.26,300,296.26,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(272,'0000000000000001','2013-07-01 17:26:45','lily','',193.8,200,193.8,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(273,'0000000000000001','2013-07-01 17:31:43','lily','',385.9,500,385.9,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(274,'0000000000000001','2013-07-01 17:32:34','lily','',160,500,160,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(275,'0000000000000001','2013-07-01 17:36:06','lily','',145.72,500,145.72,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(276,'0000000000000001','2013-07-01 17:50:31','lily','',730.25,1030.25,730.25,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(277,'0000000000000001','2013-07-01 17:52:49','lily','',99.03,100,99.03,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(278,'0000000000000001','2013-07-01 17:54:47','lily','',140.97,500,140.97,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(279,'0000000000000001','2013-07-01 17:56:13','lily','',42.56,42.6,42.56,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(280,'0000000000000001','2013-07-01 17:58:02','lily','',70.1,100,70.1,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(281,'0000000000000001','2013-07-02 08:06:19','lily','',1200,1200,1200,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(282,'0000000000000001','2013-07-02 08:07:27','lily','',150,150,150,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(283,'0000000000000001','2013-07-02 08:20:35','lily','',565.61,600,565.61,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(284,'0000000000000001','2013-07-02 08:38:28','lily','',484.18,500,484.18,'NO DISCOUNT',0,0,'3z store','','',0,'','',0,'','0000000000000001','',0),(285,'0000000000000001','2013-07-02 08:39:48','lily','',237.95,240,237.95,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(286,'0000000000000001','2013-07-02 08:40:42','lily','',130.98,135,130.98,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(287,'0000000000000001','2013-07-02 08:43:22','lily','',388.97,500,388.97,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(288,'0000000000000001','2013-07-02 08:46:00','lily','',121.73,200,121.73,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(289,'0000000000000001','2013-07-02 08:47:29','lily','',280,280,280,'NO DISCOUNT',0,0,'meliton gabas','','',0,'','',0,'','0000000000000001','',0),(290,'0000000000000001','2013-07-02 09:01:11','lily','',191,191,191,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(291,'0000000000000001','2013-07-02 09:07:08','lily','',206.79,220,206.79,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(292,'0000000000000001','2013-07-02 09:12:30','lily','',495.3,500.3,495.3,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(293,'0000000000000001','2013-07-02 09:13:23','lily','',97.5,100,97.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(294,'0000000000000001','2013-07-02 09:21:00','lily','',5,10,5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(295,'0000000000000001','2013-07-02 09:26:02','lily','',196.95,500,196.95,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(296,'0000000000000001','2013-07-02 09:33:36','lily','',1500,1500,1500,'NO DISCOUNT',0,0,'PARADISE','','',0,'','',0,'','0000000000000001','',0),(297,'0000000000000001','2013-07-02 09:40:55','lily','',191,501,191,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(298,'0000000000000001','2013-07-02 10:00:09','lily','',784.29,1000,784.29,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(299,'0000000000000001','2013-07-02 10:03:47','lily','',70.2,100,70.2,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(300,'0000000000000001','2013-07-02 10:08:33','lily','',247.47,250,247.47,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(301,'0000000000000001','2013-07-02 10:12:55','lily','',122.95,200,122.95,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(302,'0000000000000001','2013-07-02 10:15:36','lily','',149,500,149,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(303,'0000000000000001','2013-07-02 10:21:13','lily','',196.95,200,196.95,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(304,'0000000000000001','2013-07-02 10:42:29','lily','',1853.52,2000,1853.52,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(305,'0000000000000001','2013-07-02 10:44:24','lily','',1310.35,1500.35,1310.35,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(306,'0000000000000001','2013-07-02 10:44:58','lily','',20,20,20,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(307,'0000000000000001','2013-07-02 10:52:02','lily','',34,34,34,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(308,'0000000000000001','2013-07-02 10:56:47','lily','',171.6,175,171.6,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(309,'0000000000000001','2013-07-02 11:11:31','lily','',1735.91,2000,1735.91,'NO DISCOUNT',0,0,'EDA ZENAIDA PAGUIO','','',0,'','',0,'','0000000000000001','',0),(310,'0000000000000001','2013-07-02 11:14:15','lily','',166.5,500.5,166.5,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(311,'0000000000000001','2013-07-02 11:47:08','lily','',76.75,100,76.75,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(312,'0000000000000001','2013-07-02 14:09:56','lily','',1000,0,1000,'NO DISCOUNT',0,0,'sco','','',0,'','',0,'','0000000000000001','',0),(313,'0000000000000001','2013-07-02 14:13:51','lily','',1000,1000,1000,'NO DISCOUNT',0,0,'EDELWEISE','','',0,'','',0,'','0000000000000001','',0),(314,'0000000000000001','2013-07-02 14:40:43','lily','',390.35,500,390.35,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000001','',0),(315,'0000000000000003','2013-07-02 15:10:19','lily','',205,150,205,'NO DISCOUNT',0,0,'','BANKO PILIPINO','',100,'','',0,'','0000000000000003','',0),(316,'0000000000000004','2013-07-02 15:19:42',NULL,'',60,100,60,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000004','',0),(317,'0000000000000005','2013-07-02 15:22:58',NULL,'',85,100,85,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000005','',0),(318,'0000000000000006','2013-07-02 15:25:36',NULL,'',60,60,60,'SENIOR CITIZEN',5,3,'','','',0,'o','0000022',0,'','0000000000000006','',0),(319,'0000000000000007','2013-07-02 16:20:55',NULL,'',60,100,60,'SENIOR CITIZEN',5,3,'','','',0,'','',0,'','0000000000000007','',0),(320,'0000000000000008','2013-07-02 16:21:52',NULL,'',60,100,60,'SENIOR CITIZEN',5,3,'','','',0,'','',0,'','0000000000000008','',0),(321,'0000000000000009','2013-07-04 11:01:26','lily','',205,500,205,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000009','',0),(322,'0000000000000010','2013-07-04 11:18:59','lily','',205,500,205,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000010','',0),(323,'0000000000000011','2013-07-04 11:20:10','lily','',230,500,230,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000011','',0),(324,'0000000000000012','2013-07-04 15:55:26','lily','',205,500,205,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000012','',0),(325,'0000000000000013','2013-07-04 15:56:46','lily','',205,500,205,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000013','',0),(326,'0000000000000014','2013-07-04 16:01:17','lily','',205,500,205,'NO DISCOUNT',0,0,'','','',0,'','',0,'','0000000000000014','',0),(327,'0000000000000015','2013-07-07 22:30:40','lily','',545,300,545,'SENIOR CITIZEN',5,37.25,'lee super plaza','BANK OF THE PHILIPPINE ISLAND','1212121',500,'Ronald Pascua','00000002',0,'0000000000000015','Ronald Pascua','DELIVERY2 ,DELIVERY',200),(328,'0000000000000016','2013-07-07 22:31:07','lily','',80,200,80,'NO DISCOUNT',0,0,'','','',0,'','',0,'0000000000000016','','DELIVERY2',100),(329,'0000000000000017','2013-07-13 15:03:08','sample','CD-00000000014',924,1000,924,'NO DISCOUNT',0,0,'','','',0,'','',0,'0000000000000017','','',0),(330,'0000000000000018','2013-07-24 09:34:43','lily','CD-00000000015',725,300,725,'SENIOR CITIZEN',5,37.25,'rosana magdalan','BANK OF THE PHILIPPINE ISLAND','',500,'Ronald Pascua','00000001',0,'0000000000000018','APO ISLAND','DELIVERY',20),(331,'0000000000000019','2013-09-02 14:12:27','cashier','CD-00000000018',25,100,25,'NO DISCOUNT',0,0,'','','',0,'','',0,'0000000000000019','','',0),(332,'0000000000000020','2014-01-02 13:21:45','admin','',650,500,650,'SENIOR CITIZEN',5,32.5,'sample','BANK OF THE PHILIPPINE ISLAND','1212121',200,'Ronald Pascua','00000001',0,'0000000000000020','Ronald Pascua','',0),(333,'0000000000000021','2014-01-08 11:35:06','admin','',43.45,100,43.45,'NO DISCOUNT',0,0,'','','',0,'','',0,'0000000000000021','','',0),(334,'0000000000000022','2014-01-08 11:41:54','admin','',100,100,100,'NO DISCOUNT',0,0,'','','',0,'','',0,'0000000000000022','','',0);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_items`
--

DROP TABLE IF EXISTS `sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `generic_name` varchar(500) DEFAULT NULL,
  `category` varchar(500) DEFAULT NULL,
  `category_id` varchar(500) DEFAULT NULL,
  `classification` varchar(500) DEFAULT NULL,
  `classification_id` varchar(500) DEFAULT NULL,
  `sub_classification` varchar(500) DEFAULT NULL,
  `sub_classification_id` varchar(500) DEFAULT NULL,
  `product_qty` double DEFAULT NULL,
  `unit` varchar(500) DEFAULT NULL,
  `conversion` double DEFAULT NULL,
  `selling_price` double DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `item_type` varchar(500) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `session_no` varchar(100) DEFAULT NULL,
  `item_discount` varchar(100) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discount_amount` double DEFAULT NULL,
  `sales_no` varchar(100) DEFAULT NULL,
  `fixed_price` int(11) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `supplier_id` varchar(100) DEFAULT NULL,
  `vatable` int(11) DEFAULT NULL,
  `or_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=642 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_items`
--

LOCK TABLES `sales_items` WRITE;
/*!40000 ALTER TABLE `sales_items` DISABLE KEYS */;
INSERT INTO `sales_items` VALUES (217,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',1,'PC',2,200,'2013-06-28 10:46:13','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(218,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',2.046,'KILO',1,218,'2013-06-28 10:46:49','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(219,'POT','POTATO',' ','VEGETABLES','0','','0','','0',0.25,'1KL',1,60,'2013-06-28 10:49:47','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(220,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.81,'KILO',1,185,'2013-06-28 10:49:58','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(221,'O','ONIONS',' ','SPICES','0','','0','','0',0.198,'PC',1,60,'2013-06-28 10:50:15','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(222,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.538,'KILO',1,195,'2013-06-28 10:51:33','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(223,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.51,'KILO',1,195,'2013-06-28 10:52:03','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(224,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.5,'KILO',1,195,'2013-06-28 10:53:16','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(225,'EC','EGGS CRACKED',' ','EGGS','0','','0','','0',7,'PC',1,3,'2013-06-28 10:54:40','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(226,'SR','SUNRICE',' ','RICE','0','','0','','0',1,'1KL',1,39.5,'2013-06-28 10:56:09','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'JOEBON MARKETING','0',0,'0000000000000001'),(227,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',2,'KILO',1,195,'2013-06-28 11:10:45','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(228,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',4.096,'KILO',1,185,'2013-06-28 11:10:56','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(229,'S','SALT',' ','SALT','0','','0','','0',2,'1KL',0.5,3,'2013-06-28 11:11:28','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(230,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-06-28 11:12:54','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(231,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',1.118,'KILO',1,50,'2013-06-28 11:14:46','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(232,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',2.006,'KILO',1,50,'2013-06-28 11:28:50','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(233,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',1.67,'KILO',1,50,'2013-06-28 11:29:58','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(234,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.81,'KILO',1,185,'2013-06-28 11:35:02','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(235,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-06-28 11:35:19','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(236,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',6,'PC',2,200,'2013-06-28 11:48:48','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(237,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',1,'250G',0.5,17.2,'2013-06-28 11:49:36','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(238,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.94,'KILO',1,185,'2013-06-28 11:50:05','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(239,'AM','AMPALAYA',' ','VEGETABLES','0','','0','','0',0.546,'1KL',1,50,'2013-06-28 11:50:39','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(240,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',12,'PC',1,5,'2013-06-28 11:51:11','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(241,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.513,'KILO',1,185,'2013-06-28 11:51:44','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(242,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',1,'250G',0.5,17.2,'2013-06-28 11:52:18','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(243,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.736,'KILO',1,185,'2013-06-28 11:53:19','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(244,'PPT','PORK PATA',' ','FRESH MEAT','0','','0','','0',8.202,'KILO',1,120,'2013-06-28 11:55:18','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(245,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',8.094,'KILO',1,195,'2013-06-28 11:55:39','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(246,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',2,'PC',2,200,'2013-06-28 11:56:21','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(247,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.147,'KILO',1,185,'2013-06-28 11:57:59','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(248,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',5,'PC',2,200,'2013-06-28 12:00:09','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(249,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',1,'PC',0.5,50,'2013-06-28 14:09:23','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(250,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',0.724,'KILO',1,218,'2013-06-28 14:11:04','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(251,'O','ONIONS',' ','SPICES','0','','0','','0',0.33,'PC',1,60,'2013-06-28 14:11:30','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(252,'EXL','EGGS X-LARGE',' ','EGGS','0','','0','','0',12,'1KL',1,5.8,'2013-06-28 14:13:08','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(253,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',3,'250G',0.5,17.2,'2013-06-28 14:13:19','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(254,'PT','PORK TENDER - KILO',' ','FRESH MEAT','0','','0','','0',3.79,'KILO',1,195,'2013-06-28 14:16:03','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(255,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.032,'KILO',1,185,'2013-06-28 14:16:54','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(256,'EL','EGGS LARGE',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-06-28 14:17:59','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(257,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',2,'PC',30,140,'2013-06-28 14:18:27','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(258,'JL','JM LONGANIZA',' ','FROZEN ','0','','0','','0',2,'PC',1,24.25,'2013-06-28 14:19:50','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(259,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.54,'KILO',1,185,'2013-06-28 14:20:48','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(260,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',29,'250G',1,34.4,'2013-06-28 14:21:48','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(261,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.58,'KILO',1,185,'2013-06-28 14:22:16','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(262,'O','ONIONS',' ','SPICES','0','','0','','0',0.048,'PC',1,60,'2013-06-28 14:24:13','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(263,'G','GARLIC - 1KL',' ','SPICES','0','','0','','0',0.046,'1KL',1,85,'2013-06-28 14:25:05','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(264,'BAL','BALIKATAN RICE',' ','RICE','0','','0','','0',1,'1KL',1,38.45,'2013-06-28 14:26:25','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(265,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.158,'KILO',1,185,'2013-06-28 14:26:55','lily','',0,'CD-00000000008','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(266,'EL','EGGS LARGE',' ','EGGS','0','','0','','0',5,'PC',1,5.3,'2013-06-28 14:27:41','lily','',0,'CD-00000000008','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(267,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',3,'PC',1,5,'2013-06-29 08:24:02','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(268,'BAL','BALIKATAN RICE',' ','RICE','0','','0','','0',1,'1KL',1,38.45,'2013-06-29 08:32:51','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(269,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.92,'KILO',1,185,'2013-06-29 08:38:14','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(270,'O','ONIONS',' ','SPICES','0','','0','','0',0.262,'PC',1,60,'2013-06-29 08:39:50','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(271,'G','GARLIC - 1KL',' ','SPICES','0','','0','','0',0.188,'1KL',1,85,'2013-06-29 08:40:56','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(272,'PT','PORK TENDER',' ','FRESH MEAT','0','','0','','0',0.88,'KILO',1,195,'2013-06-29 08:51:33','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(273,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.748,'KILO',1,185,'2013-06-29 08:51:41','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(274,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',3.264,'KILO',1,185,'2013-06-29 08:53:25','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(275,'PT','PORK TENDER',' ','FRESH MEAT','0','','0','','0',0.748,'KILO',1,195,'2013-06-29 08:54:06','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(276,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.012,'KILO',1,195,'2013-06-29 08:54:18','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(277,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',2.05,'KILO',1,218,'2013-06-29 08:54:35','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(278,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.932,'KILO',1,185,'2013-06-29 08:56:02','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(279,'MO','MONGO',' ','VEGETABLES','0','','0','','0',1,'1KL',0.25,15,'2013-06-29 08:56:13','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(280,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-06-29 08:57:51','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(281,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.22,'KILO',1,185,'2013-06-29 08:58:52','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(282,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.702,'KILO',1,195,'2013-06-29 08:59:00','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(283,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',0.976,'KILO',1,218,'2013-06-29 08:59:08','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(284,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.768,'KILO',1,195,'2013-06-29 08:59:42','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(285,'EL','EGGS LARGE',' ','EGGS','0','','0','','0',3,'PC',30,150,'2013-06-29 09:03:32','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(286,'EL','EGGS LARGE',' ','EGGS','0','','0','','0',10,'PC',30,150,'2013-06-29 09:09:37','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(287,'JL','JM LONGANIZA',' ','FROZEN ','0','','0','','0',2,'PC',1,24.25,'2013-06-29 09:16:28','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(288,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',10,'PC',1,5,'2013-06-29 09:16:49','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(289,'EXL','EGGS X-LARGE',' ','EGGS','0','','0','','0',6,'1KL',1,5.8,'2013-06-29 09:17:23','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(290,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.574,'KILO',1,185,'2013-06-29 09:17:37','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(291,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.926,'KILO',1,185,'2013-06-29 09:26:23','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(292,'EL','EGGS LARGE',' ','EGGS','0','','0','','0',12,'PC',1,5.3,'2013-06-29 09:32:19','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(293,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.994,'KILO',1,185,'2013-06-29 09:32:36','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(294,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',1,'KILO',1,195,'2013-06-29 09:33:06','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(295,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.118,'KILO',1,185,'2013-06-29 09:35:19','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(296,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-06-29 09:35:33','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(297,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.39,'KILO',1,185,'2013-06-29 09:45:46','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(298,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.584,'KILO',1,185,'2013-06-29 10:05:23','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(299,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.512,'KILO',1,195,'2013-06-29 10:05:46','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(300,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',1,'PC',1,100,'2013-06-29 10:05:57','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(301,'EL','EGGS LARGE',' ','EGGS','0','','0','','0',12,'PC',1,5.3,'2013-06-29 10:06:10','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(302,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',5.198,'KILO',1,50,'2013-06-29 10:15:05','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(303,'G','GARLIC - 1KL',' ','SPICES','0','','0','','0',0.056,'1KL',1,85,'2013-06-29 10:19:18','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(304,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.34,'KILO',1,185,'2013-06-29 10:30:07','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(305,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.25,'KILO',1,195,'2013-06-29 10:30:17','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(306,'G','GARLIC - 1KL',' ','SPICES','0','','0','','0',0.05,'1KL',1,85,'2013-06-29 10:30:43','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(307,'O','ONIONS',' ','SPICES','0','','0','','0',0.112,'PC',1,60,'2013-06-29 10:30:58','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(308,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',0.844,'KILO',1,80,'2013-06-29 10:31:51','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(309,'MO','MONGO',' ','VEGETABLES','0','','0','','0',1,'1KL',0.25,15,'2013-06-29 10:32:00','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(310,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-06-29 10:32:40','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(311,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',5.894,'KILO',1,185,'2013-06-29 10:33:02','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(312,'PT','PORK TENDER',' ','FRESH MEAT','0','','0','','0',0.852,'KILO',1,195,'2013-06-29 10:33:38','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(313,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.556,'KILO',1,195,'2013-06-29 10:33:46','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(314,'MO','MONGO',' ','VEGETABLES','0','','0','','0',1,'1KL',0.25,15,'2013-06-29 10:33:55','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(315,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',0.778,'KILO',1,80,'2013-06-29 10:34:10','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(316,'EL','EGGS LARGE',' ','EGGS','0','','0','','0',12,'PC',1,5.3,'2013-06-29 10:34:19','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(317,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.294,'KILO',1,185,'2013-06-29 10:38:44','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(318,'WB','WHITE BEANS ',' ','VEGETABLES','0','','0','','0',1,'1KL',0.25,17.5,'2013-06-29 10:38:58','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(319,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',1.748,'KILO',1,50,'2013-06-29 10:43:06','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(320,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',3,'PC',2,200,'2013-06-29 10:44:47','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(321,'fp','FROZEN PEAS',' ','FROZEN ','0','','0','','0',5,'1KL',1,130,'2013-06-29 10:44:57','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(322,'AM','AMPALAYA',' ','VEGETABLES','0','','0','','0',3.5,'1KL',1,50,'2013-06-29 10:47:46','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(323,'TP','PECHAY TAIWAN - 1KL',' ','VEGETABLES','0','','0','','0',2.72,'1KL',1,60,'2013-06-29 10:50:54','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(324,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',6.5,'KILO',1,218,'2013-06-29 10:52:45','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(325,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',4.088,'KILO',1,185,'2013-06-29 10:52:55','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(326,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',4,'PC',2,200,'2013-06-29 11:04:18','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(327,'EL','EGGS LARGE  - TRAY-30',' ','EGGS','0','','0','','0',45,'TRAY-30',30,146,'2013-06-29 11:07:11','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(328,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',5,'PC',30,140,'2013-06-29 11:07:27','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(329,'YDR5','YELLOW DRAGON RICE 5KLS',' ','RICE','0','','0','','0',1,'PC',1,191,'2013-06-29 11:12:04','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(330,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.54,'KILO',1,185,'2013-06-29 11:12:32','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(331,'YDR','YELLOW DRAGON RICE - 1KL',' ','RICE','0','','0','','0',2,'1KL',1,191,'2013-06-29 11:14:14','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(332,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.595,'KILO',1,185,'2013-06-29 11:14:45','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(333,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',2,'PC',1,10,'2013-06-29 11:15:19','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(334,'EL','EGGS LARGE  - TRAY-30',' ','EGGS','0','','0','','0',5,'TRAY-30',30,146,'2013-06-29 11:31:06','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(335,'EC','EGGS CRACKED - PC',' ','EGGS','0','','0','','0',11,'PC',1,3,'2013-06-29 11:38:40','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(336,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',3,'PC',30,140,'2013-06-29 11:47:55','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(337,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.66,'KILO',1,185,'2013-06-29 11:49:45','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(338,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.226,'KILO',1,195,'2013-06-29 11:49:56','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(339,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',3,'PC',1,5,'2013-06-29 11:50:06','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(340,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.192,'KILO',1,185,'2013-06-29 14:00:13','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(341,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.284,'KILO',1,195,'2013-06-29 14:00:32','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(342,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.288,'KILO',1,195,'2013-06-29 14:00:41','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(343,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',5,'PC',2,200,'2013-06-29 14:03:01','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(344,'fp','FROZEN PEAS',' ','FROZEN ','0','','0','','0',1,'1KL',0.5,65,'2013-06-29 14:16:57','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(345,'EL','EGGS LARGE  - TRAY-30',' ','EGGS','0','','0','','0',1,'TRAY-30',30,150,'2013-06-29 14:18:51','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(346,'EL','EGGS LARGE  - TRAY-30',' ','EGGS','0','','0','','0',2,'TRAY-30',30,150,'2013-06-29 14:41:09','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(347,'4806518440019','SEA WORLD TEMPURA 500g',' ','FROZEN ','0','','0','','0',2,'PC',1,72.75,'2013-06-29 14:48:18','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'SEA WORLD ','0',0,'0000000000000001'),(348,'CT','CHICKEN THIGH',' ','FRESH MEAT','0','','0','','0',0.842,'KILO',1,143,'2013-06-29 14:49:25','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(349,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.858,'KILO',1,195,'2013-06-29 14:49:36','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(350,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.548,'KILO',1,185,'2013-06-29 14:49:51','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(351,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',1,'PC',1,100,'2013-06-29 14:50:36','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(352,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.76,'KILO',1,185,'2013-06-29 14:51:09','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(353,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',1,'PC',0.5,50,'2013-06-29 14:52:01','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(354,'POT','POTATO',' ','VEGETABLES','0','','0','','0',0.674,'1KL',1,60,'2013-06-29 14:58:37','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(355,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',5,'PC',2,200,'2013-06-29 15:00:44','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(356,'POT','POTATO',' ','VEGETABLES','0','','0','','0',0.66,'1KL',1,60,'2013-06-29 15:06:17','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(357,'O','ONION',' ','SPICES','0','','0','','0',0.508,'1KL',1,60,'2013-06-29 15:06:25','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(358,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',1,'KILO',1,195,'2013-06-29 15:06:36','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(359,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',2.42,'KILO',1,195,'2013-06-29 15:07:02','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(360,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',15,'PC',1,5,'2013-06-29 15:07:13','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(361,'SIL','SILAY - 1KL',' ','DRIED FISH','0','','0','','0',0.074,'1KL',1,250,'2013-06-29 15:10:01','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'CINDY & NICO DRIED FISH DEALER','0',0,'0000000000000001'),(362,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',12,'PC',1,5,'2013-06-29 15:25:17','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(363,'SR','SUNRICE',' ','RICE','0','','0','','0',10,'1KL',1,39.5,'2013-06-29 15:57:34','admin','',0,'','',0,0,'0000000000000001',1,'JOEBON MARKETING','0',0,'0000000000000001'),(364,'TANG','TANGKONG',' ','VEGETABLES','0','','0','','0',1,'PC',1,5,'2013-06-29 15:58:12','admin','',0,'','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(365,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',1.704,'KILO',1,50,'2013-06-29 16:00:10','admin','',0,'','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(366,'NP','NATIVE PECHAY 250G - PC',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-06-29 16:00:48','admin','',0,'','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(367,'EL','EGGS LARGE  - TRAY-30',' ','EGGS','0','','0','','0',3,'TRAY-30',30,150,'2013-06-29 16:01:53','admin','',0,'','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(368,'fp','FROZEN PEAS',' ','FROZEN ','0','','0','','0',1,'1KL',1,130,'2013-06-29 16:11:03','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(369,'fp','FROZEN PEAS',' ','FROZEN ','0','','0','','0',3,'1KL',1,130,'2013-06-29 16:13:11','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(370,'4806518440019','SEA WORLD TEMPURA 500g',' ','FROZEN ','0','','0','','0',1,'PC',1,72.75,'2013-06-29 16:45:47','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'SEA WORLD ','0',0,'0000000000000001'),(371,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',1,'PC',30,140,'2013-06-29 16:45:53','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(372,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.7,'KILO',1,195,'2013-06-29 16:46:08','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(373,'CD','CHICKEN DRUMSTICK',' ','FRESH MEAT','0','','0','','0',1.356,'KILO',1,143,'2013-06-29 17:02:28','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'BOUNTY FRESH','BOUNTY FRESH',0,'0000000000000001'),(374,'S','SALT',' ','SALT','0','','0','','0',4,'1KL',0.5,3,'2013-06-29 17:02:42','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(375,'RS','REFINED SUGAR',' ','SUGAR','0','','0','','0',1,'250G',1,42.7,'2013-06-29 17:02:58','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(376,'MO','MONGO',' ','VEGETABLES','0','','0','','0',2,'1KL',0.5,30,'2013-06-29 17:03:08','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(377,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',2.861,'KILO',1,185,'2013-06-29 17:06:37','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(378,'G','GARLIC',' ','SPICES','0','','0','','0',0.178,'1KL',1,85,'2013-06-29 17:07:05','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(379,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.27,'KILO',1,185,'2013-06-29 17:09:44','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(380,'NMR5','NEW MOON RICE 5KLS - PC',' ','RICE','0','','0','','0',2,'PC',1,189,'2013-06-29 17:14:15','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'BM CEREAL','BM CEREAL',0,'0000000000000001'),(381,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.037,'KILO',1,185,'2013-06-29 17:16:44','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(382,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-06-29 17:18:02','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(383,'YDR','YELLOW DRAGON RICE - 1KL',' ','RICE','0','','0','','0',1,'1KL',1,191,'2013-06-29 17:18:43','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(384,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',4.286,'KILO',1,80,'2013-06-29 17:20:47','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(385,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',1,'250G',0.5,17.2,'2013-06-29 17:21:48','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(386,'SIL','SILAY - 1KL',' ','DRIED FISH','0','','0','','0',0.088,'1KL',1,250,'2013-06-29 17:22:22','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'CINDY & NICO DRIED FISH DEALER','0',0,'0000000000000001'),(387,'NMR5','NEW MOON RICE 5KLS - PC',' ','RICE','0','','0','','0',1,'PC',1,189,'2013-06-29 17:23:07','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'BM CEREAL','BM CEREAL',0,'0000000000000001'),(388,'SR5','SUNRICE 5KLS',' ','RICE','0','','0','','0',1,'1KL',1,202.65,'2013-06-29 17:23:22','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'JOEBON MARKETING','0',0,'0000000000000001'),(389,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',2,'PC',30,140,'2013-06-29 17:27:14','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(390,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',2.872,'KILO',1,185,'2013-06-29 17:29:01','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(391,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.262,'KILO',1,185,'2013-06-29 17:31:02','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(392,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',1.028,'KILO',1,50,'2013-06-29 17:32:58','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(393,'O','ONION',' ','SPICES','0','','0','','0',1.126,'1KL',1,60,'2013-06-29 17:36:06','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(394,'G','GARLIC',' ','SPICES','0','','0','','0',0.354,'1KL',1,85,'2013-06-29 17:36:18','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(395,'MO','MONGO',' ','VEGETABLES','0','','0','','0',1,'1KL',0.5,30,'2013-06-29 17:36:31','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(396,'JH','JM HAMONADA',' ','FROZEN ','0','','0','','0',4,'PC',1,33,'2013-06-29 17:37:23','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(397,'JL','JM LONGANIZA',' ','FROZEN ','0','','0','','0',4,'PC',1,24.25,'2013-06-29 17:37:54','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(398,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-06-29 17:38:28','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(399,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-06-29 17:44:21','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(400,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',3,'PC',30,150,'2013-06-29 17:53:04','lily','',0,'CD-00000000009','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(401,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',1.692,'KILO',1,80,'2013-06-29 18:00:23','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(402,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',0.834,'KILO',1,80,'2013-06-29 18:05:36','lily','',0,'CD-00000000009','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(403,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-01 08:34:35','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(404,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.534,'KILO',1,195,'2013-07-01 08:35:11','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(405,'EXL','EGGS X-LARGE',' ','EGGS','0','','0','','0',2,'1KL',30,170,'2013-07-01 08:36:55','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(406,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.4,'KILO',1,195,'2013-07-01 08:38:48','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(407,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.668,'KILO',1,185,'2013-07-01 08:38:56','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(408,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.004,'KILO',1,195,'2013-07-01 08:41:37','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(409,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.0259,'KILO',1,185,'2013-07-01 08:41:59','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(410,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-01 08:42:20','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(411,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',4,'PC',30,140,'2013-07-01 08:43:36','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(412,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',3.464,'KILO',1,185,'2013-07-01 08:45:08','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(413,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.628,'KILO',1,195,'2013-07-01 08:45:47','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(414,'O','ONION - 1KL',' ','SPICES','0','','0','','0',0.238,'1KL',1,60,'2013-07-01 08:47:39','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(415,'G','GARLIC',' ','SPICES','0','','0','','0',0.132,'1KL',1,85,'2013-07-01 08:47:52','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(416,'EC','EGGS CRACKED',' ','EGGS','0','','0','','0',5,'PC',1,3,'2013-07-01 08:48:40','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(417,'T','TOMATO - 1KL',' ','VEGETABLES','0','','0','','0',0.362,'1KL',1,30,'2013-07-01 08:50:42','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(418,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',1.668,'KILO',1,80,'2013-07-01 08:53:38','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(419,'EXL','EGGS X-LARGE',' ','EGGS','0','','0','','0',12,'1KL',1,5.8,'2013-07-01 08:53:48','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(420,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-01 08:53:58','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(421,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',2,'PC',30,140,'2013-07-01 08:57:07','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(422,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',2.394,'KILO',1,185,'2013-07-01 08:57:24','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(423,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.75,'KILO',1,195,'2013-07-01 08:57:37','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(424,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.5,'KILO',1,195,'2013-07-01 09:10:16','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(425,'O','ONION',' ','SPICES','0','','0','','0',0.366,'1KL',1,60,'2013-07-01 09:17:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(426,'C','CALAMANSI 100\'S - PC',' ','FRUITS','0','','0','','0',0.5,'PC',1,40,'2013-07-01 09:18:04','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(427,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',2.022,'KILO',1,185,'2013-07-01 09:18:38','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(428,'CW','CHICKEN WINGS',' ','FRESH MEAT','0','','0','','0',0.975,'KILO',1,143,'2013-07-01 09:18:54','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(429,'G','GARLIC',' ','SPICES','0','','0','','0',0.248,'1KL',1,85,'2013-07-01 09:19:07','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(430,'MO','MONGO',' ','VEGETABLES','0','','0','','0',1,'1KL',0.5,30,'2013-07-01 09:19:17','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(431,'RS','REFINED SUGAR',' ','SUGAR','0','','0','','0',2,'250G',1,42.7,'2013-07-01 09:19:57','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(432,'S','SALT',' ','SALT','0','','0','','0',1,'1KL',0.5,3,'2013-07-01 09:20:30','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(433,'JL','JM LONGANIZA',' ','FROZEN ','0','','0','','0',2,'PC',1,24.25,'2013-07-01 09:20:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(434,'YDR5','YELLOW DRAGON RICE 5KLS',' ','RICE','0','','0','','0',1,'PC',1,191,'2013-07-01 09:21:25','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(435,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',1,'250G',1,34.4,'2013-07-01 09:21:37','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(436,'MO','MONGO - 250G',' ','VEGETABLES','0','','0','','0',1,'250G',0.25,15,'2013-07-01 09:22:43','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(437,'POT','POTATO',' ','VEGETABLES','0','','0','','0',1.088,'1KL',1,60,'2013-07-01 09:25:12','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(438,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',2,'PC',1,10,'2013-07-01 09:25:37','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(439,'JH','JM HAMONADA',' ','FROZEN ','0','','0','','0',2,'PC',1,33,'2013-07-01 09:25:57','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(440,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.567,'KILO',1,195,'2013-07-01 09:26:15','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(441,'EC','EGGS CRACKED',' ','EGGS','0','','0','','0',12,'PC',1,3,'2013-07-01 09:26:29','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(442,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.492,'KILO',1,185,'2013-07-01 09:30:09','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(443,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.348,'KILO',1,185,'2013-07-01 09:31:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(444,'O','ONION',' ','SPICES','0','','0','','0',0.086,'1KL',1,60,'2013-07-01 09:32:28','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(445,'G','GARLIC',' ','SPICES','0','','0','','0',0.054,'1KL',1,85,'2013-07-01 09:33:12','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(446,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',4,'PC',1,5,'2013-07-01 09:34:11','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(447,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',1,'PC',30,140,'2013-07-01 09:39:37','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(448,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',5,'PC',30,140,'2013-07-01 09:41:15','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(449,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.256,'KILO',1,195,'2013-07-01 09:43:32','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(450,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.5,'KILO',1,195,'2013-07-01 09:51:47','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(451,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',0.47,'KILO',1,218,'2013-07-01 09:51:56','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(452,'EP','EGGPLANT - 1KL',' ','VEGETABLES','0','','0','','0',0.514,'1KL',1,30,'2013-07-01 09:53:03','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(453,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',0.564,'KILO',1,218,'2013-07-01 09:55:02','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(454,'SR','SUNRICE',' ','RICE','0','','0','','0',1,'1KL',1,39.5,'2013-07-01 09:55:41','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JOEBON MARKETING','0',0,'0000000000000001'),(455,'EC','EGGS CRACKED',' ','EGGS','0','','0','','0',5,'PC',1,3,'2013-07-01 09:55:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(456,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.576,'KILO',1,195,'2013-07-01 10:06:06','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(457,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.198,'KILO',1,185,'2013-07-01 10:06:15','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(458,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.882,'KILO',1,195,'2013-07-01 10:09:39','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(459,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.016,'KILO',1,195,'2013-07-01 10:25:23','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(460,'CH','CHICHARON',' ','','0','','0','','0',1,'PC',1,20,'2013-07-01 10:57:48','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JUDITH MAQUILING',NULL,0,'0000000000000001'),(461,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',4.752,'KILO',1,195,'2013-07-01 11:55:49','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(462,'O','ONION',' ','SPICES','0','','0','','0',0.348,'1KL',1,60,'2013-07-01 13:59:47','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(463,'G','GARLIC',' ','SPICES','0','','0','','0',0.05,'1KL',1,85,'2013-07-01 13:59:57','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(464,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',7.102,'KILO',1,50,'2013-07-01 14:11:40','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(465,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',3,'PC',2,200,'2013-07-01 14:14:16','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(466,'JL','JM LONGANIZA',' ','FROZEN ','0','','0','','0',2,'PC',1,24.25,'2013-07-01 14:42:43','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(467,'JH','JM HAMONADA',' ','FROZEN ','0','','0','','0',1,'PC',1,33,'2013-07-01 14:42:53','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(468,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.432,'KILO',1,195,'2013-07-01 15:23:49','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(469,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.25,'KILO',1,195,'2013-07-01 15:24:02','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(470,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.522,'KILO',1,195,'2013-07-01 15:26:38','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(471,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.366,'KILO',1,185,'2013-07-01 15:29:23','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(472,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.672,'KILO',1,195,'2013-07-01 15:30:11','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(473,'CW','CHICKEN WINGS',' ','FRESH MEAT','0','','0','','0',0.692,'KILO',1,143,'2013-07-01 15:30:25','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(474,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',2,'PC',2,200,'2013-07-01 15:33:22','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(475,'4806518440002','SEA WORLD TEMPURA 1KL',' ','FROZEN ','0','','0','','0',6,'PC',1,145.5,'2013-07-01 15:33:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'SEA WORLD ','0',0,'0000000000000001'),(476,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',4,'PC',30,140,'2013-07-01 15:37:42','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(477,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',1,'PC',30,140,'2013-07-01 15:38:29','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(478,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.876,'KILO',1,185,'2013-07-01 15:40:31','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(479,'G','GARLIC',' ','SPICES','0','','0','','0',0.154,'1KL',1,85,'2013-07-01 15:40:44','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(480,'O','ONION',' ','SPICES','0','','0','','0',0.358,'1KL',1,60,'2013-07-01 15:40:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(481,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.51,'KILO',1,195,'2013-07-01 16:00:32','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(482,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-01 16:32:34','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(483,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.138,'KILO',1,185,'2013-07-01 16:34:38','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(484,'O','ONION',' ','SPICES','0','','0','','0',0.038,'1KL',1,60,'2013-07-01 16:34:46','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(485,'G','GARLIC',' ','SPICES','0','','0','','0',0.014,'1KL',1,85,'2013-07-01 16:35:03','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(486,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',2,'PC',30,150,'2013-07-01 16:51:53','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(487,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',0.348,'KILO',1,218,'2013-07-01 16:59:57','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(488,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',2,'PC',30,150,'2013-07-01 17:00:48','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(489,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.47,'KILO',1,185,'2013-07-01 17:01:54','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(490,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.206,'KILO',1,195,'2013-07-01 17:02:05','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(491,'MO','MONGO',' ','VEGETABLES','0','','0','','0',1,'1KL',0.25,15,'2013-07-01 17:02:12','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'WINBEE MARKETING','0',0,'0000000000000001'),(492,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-01 17:14:17','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(493,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',1,'KILO',1,195,'2013-07-01 17:14:26','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(494,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.588,'KILO',1,185,'2013-07-01 17:14:39','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(495,'DFK','DRIED FISH KARBALYAS',' ','DRIED FISH','0','','0','','0',0.076,'1KL',1,230,'2013-07-01 17:14:52','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'CINDY & NICO DRIED FISH DEALER','0',0,'0000000000000001'),(496,'DFK','DRIED FISH KARBALYAS',' ','DRIED FISH','0','','0','','0',0.06,'1KL',1,230,'2013-07-01 17:16:27','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'CINDY & NICO DRIED FISH DEALER','0',0,'0000000000000001'),(497,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.348,'KILO',1,185,'2013-07-01 17:16:42','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(498,'JL','JM LONGANIZA',' ','FROZEN ','0','','0','','0',1,'PC',1,24.25,'2013-07-01 17:16:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(499,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',2,'PC',1,5,'2013-07-01 17:17:01','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(500,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-01 17:17:16','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(501,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.55,'KILO',1,185,'2013-07-01 17:19:29','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(502,'ALUG','ALUGBATI',' ','VEGETABLES','0','','0','','0',1,'1KL',1,5,'2013-07-01 17:20:17','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(503,'OK','OKRA',' ','VEGETABLES','0','','0','','0',1,'PC',1,6,'2013-07-01 17:20:25','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(504,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.624,'KILO',1,185,'2013-07-01 17:21:29','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(505,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',2,'PC',2,200,'2013-07-01 17:22:54','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(506,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.506,'KILO',1,185,'2013-07-01 17:23:38','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(507,'SR5','SUNRICE 5KLS',' ','RICE','0','','0','','0',1,'1KL',1,202.65,'2013-07-01 17:23:48','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JOEBON MARKETING','0',0,'0000000000000001'),(508,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-01 17:25:39','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(509,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',0.876,'KILO',1,50,'2013-07-01 17:26:07','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(510,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.998,'KILO',1,195,'2013-07-01 17:30:37','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(511,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.034,'KILO',1,185,'2013-07-01 17:30:46','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(512,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-01 17:32:02','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(513,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-01 17:32:08','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(514,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-01 17:34:43','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(515,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.552,'KILO',1,195,'2013-07-01 17:34:50','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(516,'POT','POTATO',' ','VEGETABLES','0','','0','','0',0.468,'1KL',1,60,'2013-07-01 17:35:33','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(517,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-01 17:47:38','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(518,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.868,'KILO',1,185,'2013-07-01 17:47:51','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(519,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',1.026,'KILO',1,218,'2013-07-01 17:48:07','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(520,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.026,'KILO',1,195,'2013-07-01 17:48:21','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(521,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',3,'250G',0.5,17.2,'2013-07-01 17:48:39','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(522,'RS','REFINED SUGAR',' ','SUGAR','0','','0','','0',2,'250G',0.5,21.35,'2013-07-01 17:48:53','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(523,'O','ONION',' ','SPICES','0','','0','','0',0.334,'1KL',1,60,'2013-07-01 17:49:05','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(524,'G','GARLIC',' ','SPICES','0','','0','','0',0.254,'1KL',1,85,'2013-07-01 17:49:16','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(525,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.394,'KILO',1,195,'2013-07-01 17:52:13','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(526,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',1,'250G',0.5,17.2,'2013-07-01 17:52:23','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(527,'TANG','TANGKONG',' ','VEGETABLES','0','','0','','0',1,'PC',1,5,'2013-07-01 17:52:32','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(528,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.762,'KILO',1,185,'2013-07-01 17:54:07','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(529,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',0.476,'KILO',1,50,'2013-07-01 17:55:13','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(530,'G','GARLIC',' ','SPICES','0','','0','','0',0.112,'1KL',1,85,'2013-07-01 17:55:25','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(531,'O','ONION',' ','SPICES','0','','0','','0',0.154,'1KL',1,60,'2013-07-01 17:55:32','lily','',0,'CD-00000000010','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(532,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',7,'PC',1,5.3,'2013-07-01 17:56:54','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(533,'JH','JM HAMONADA',' ','FROZEN ','0','','0','','0',1,'PC',1,33,'2013-07-01 17:57:16','lily','',0,'CD-00000000010','',0,0,'0000000000000001',1,'JUDITH MAQUILING','0',0,'0000000000000001'),(534,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',6,'PC',2,200,'2013-07-02 08:05:17','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(535,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-02 08:07:18','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(536,'PSA','PORK SALISI',' ','FRESH MEAT','0','','0','','0',1.444,'KILO',1,80,'2013-07-02 08:17:23','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(537,'PSK','PORK SKINLESS',' ','FRESH MEAT','0','','0','','0',1.514,'KILO',1,185,'2013-07-02 08:18:03','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(538,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',2,'PC',1,10,'2013-07-02 08:18:22','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(539,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-02 08:19:10','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(540,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',3,'PC',30,150,'2013-07-02 08:35:04','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(541,'S','SALT',' ','SALT','0','','0','','0',3,'1KL',0.5,3,'2013-07-02 08:35:43','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(542,'O','ONION',' ','SPICES','0','','0','','0',0.244,'1KL',1,60,'2013-07-02 08:37:26','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(543,'G','GARLIC',' ','SPICES','0','','0','','0',0.124,'1KL',1,85,'2013-07-02 08:37:37','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(544,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.736,'KILO',1,185,'2013-07-02 08:38:52','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(545,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.522,'KILO',1,195,'2013-07-02 08:39:11','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(546,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.708,'KILO',1,185,'2013-07-02 08:40:14','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(547,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.732,'KILO',1,185,'2013-07-02 08:41:05','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(548,'GG','GALAY GREEN',' ','VEGETABLES','0','','0','','0',1,'PC',1,5,'2013-07-02 08:41:20','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(549,'S','SALT',' ','SALT','0','','0','','0',1,'1KL',0.5,3,'2013-07-02 08:41:28','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(550,'BT','BEEF TENDERLOIN',' ','FRESH MEAT','0','','0','','0',1.024,'KILO',1,218,'2013-07-02 08:42:38','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(551,'O','ONION',' ','SPICES','0','','0','','0',0.372,'1KL',1,60,'2013-07-02 08:42:49','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(552,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.658,'KILO',1,185,'2013-07-02 08:45:24','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(553,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',2,'PC',30,140,'2013-07-02 08:47:10','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(554,'YDR5','YELLOW DRAGON RICE 5KLS',' ','RICE','0','','0','','0',1,'PC',1,191,'2013-07-02 09:00:48','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(555,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.514,'KILO',1,195,'2013-07-02 09:06:05','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(556,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.576,'KILO',1,185,'2013-07-02 09:06:12','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(557,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.514,'KILO',1,195,'2013-07-02 09:11:47','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(558,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',1.026,'KILO',1,195,'2013-07-02 09:11:59','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(559,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.5,'KILO',1,195,'2013-07-02 09:13:08','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(560,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',1,'PC',1,5,'2013-07-02 09:20:49','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(561,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.476,'KILO',1,185,'2013-07-02 09:25:14','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(562,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.502,'KILO',1,195,'2013-07-02 09:25:22','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(563,'TANG','TANGKONG',' ','VEGETABLES','0','','0','','0',1,'PC',1,5,'2013-07-02 09:25:34','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(564,'OK','OKRA',' ','VEGETABLES','0','','0','','0',1,'PC',1,6,'2013-07-02 09:25:39','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(565,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',10,'PC',30,150,'2013-07-02 09:33:08','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(566,'YDR5','YELLOW DRAGON RICE 5KLS',' ','RICE','0','','0','','0',1,'PC',1,191,'2013-07-02 09:40:40','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(567,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',1.014,'KILO',1,185,'2013-07-02 09:53:04','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(568,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',1.5,'KILO',1,195,'2013-07-02 09:54:21','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(569,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.56,'KILO',1,195,'2013-07-02 09:54:30','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(570,'TP','PECHAY TAIWAN - 1KL',' ','VEGETABLES','0','','0','','0',1.17,'1KL',1,60,'2013-07-02 10:03:17','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(571,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.922,'KILO',1,185,'2013-07-02 10:05:15','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(572,'BAL','BALIKATAN RICE - 2KLS',' ','RICE','0','','0','','0',1,'2KLS',2,76.9,'2013-07-02 10:07:54','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(573,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',0.25,'KILO',1,195,'2013-07-02 10:12:14','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(574,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.32,'KILO',1,185,'2013-07-02 10:12:23','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(575,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-02 10:12:29','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(576,'TANG','TANGKONG',' ','VEGETABLES','0','','0','','0',1,'PC',1,5,'2013-07-02 10:12:36','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(577,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',2.98,'KILO',1,50,'2013-07-02 10:15:04','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(578,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.01,'KILO',1,195,'2013-07-02 10:20:51','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(579,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',12,'PC',1,5.3,'2013-07-02 10:39:31','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(580,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',7.583,'KILO',1,195,'2013-07-02 10:39:43','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(581,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',2,'PC',1,10,'2013-07-02 10:39:56','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(582,'PG','PORK GROUND',' ','FRESH MEAT','0','','0','','0',1,'KILO',1,195,'2013-07-02 10:40:07','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(583,'EM','EGGS MEDIUM',' ','EGGS','0','','0','','0',12,'PC',1,5,'2013-07-02 10:40:18','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'QUIAMCO FARM','0',0,'0000000000000001'),(584,'O','ONION',' ','SPICES','0','','0','','0',0.17,'1KL',1,60,'2013-07-02 10:41:21','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(585,'POT','POTATO',' ','VEGETABLES','0','','0','','0',0.434,'1KL',1,60,'2013-07-02 10:41:34','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'WINBEE MARKETING','0',0,'0000000000000001'),(586,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',2.02,'KILO',1,185,'2013-07-02 10:43:05','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(587,'PSK','PORK SKINLESS',' ','FRESH MEAT','0','','0','','0',4.03,'KILO',1,185,'2013-07-02 10:43:34','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(588,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.98,'KILO',1,195,'2013-07-02 10:43:44','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(589,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',2,'PC',1,10,'2013-07-02 10:44:50','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(590,'P','PARSLEY',' ','VEGETABLES','0','','0','','0',0.2,'KILO',1,170,'2013-07-02 10:51:41','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(591,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.88,'KILO',1,195,'2013-07-02 10:56:15','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(592,'CT','CHICKEN THIGH',' ','FRESH MEAT','0','','0','','0',2.51,'KILO',1,143,'2013-07-02 10:59:56','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(593,'CBONES','CHICKEN BONES',' ','FRESH MEAT','0','','0','','0',2.8259999999999996,'KILO',1,50,'2013-07-02 11:00:20','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'BOUNTY FRESH','0',0,'0000000000000001'),(594,'O','ONION',' ','SPICES','0','','0','','0',1.014,'1KL',1,60,'2013-07-02 11:00:29','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000001'),(595,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',1.622,'KILO',1,195,'2013-07-02 11:00:46','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(596,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'PC',30,150,'2013-07-02 11:03:01','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(597,'EL2','EGGS LARGE  - PC',' ','EGGS','0','','0','','0',12,'PC',1,5.3,'2013-07-02 11:03:47','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(598,'NP','NATIVE PECHAY 250G - PC',' ','VEGETABLES','0','','0','','0',4,'PC',1,10,'2013-07-02 11:04:08','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(599,'RS','REFINED SUGAR',' ','SUGAR','0','','0','','0',1,'250G',0.5,21.35,'2013-07-02 11:04:49','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(600,'YDR','YELLOW DRAGON RICE - 1KL',' ','RICE','0','','0','','0',2,'1KL',1,191,'2013-07-02 11:05:23','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'BM CEREAL','0',0,'0000000000000001'),(601,'EL','EGGS LARGE ',' ','EGGS','0','','0','','0',1,'TRAY-30',30,150,'2013-07-02 11:05:38','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','QUIAMCO FARM',0,'0000000000000001'),(602,'CS','CENTRIFUGALSUGAR',' ','SUGAR','0','','0','','0',3,'250G',0.5,17.2,'2013-07-02 11:07:47','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'NEW BIAN YEK COMMERCIAL','0',0,'0000000000000001'),(603,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',0.9,'KILO',1,185,'2013-07-02 11:13:43','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(604,'PPA','PORK PAA',' ','FRESH MEAT','0','','0','','0',0.25,'KILO',1,195,'2013-07-02 11:46:04','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(605,'NP','NATIVE PECHAY 250G',' ','VEGETABLES','0','','0','','0',1,'PC',1,10,'2013-07-02 11:46:18','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(606,'EC','EGGS CRACKED',' ','EGGS','0','','0','','0',6,'PC',1,3,'2013-07-02 11:46:23','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'QUIAMCO FARM','0',0,'0000000000000001'),(607,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',5,'PC',2,200,'2013-07-02 14:09:29','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(608,'FF','FRENCH FRIES ',' ','FROZEN ','0','','0','','0',5,'PC',2,200,'2013-07-02 14:13:11','lily','',0,'CD-00000000011','',0,0,'0000000000000001',1,'S&R MEMBERSHIP','0',0,'0000000000000001'),(609,'PWS','PORK W/ SKIN',' ','FRESH MEAT','0','','0','','0',2.11,'KILO',1,185,'2013-07-02 14:40:16','lily','',0,'CD-00000000011','',0,0,'0000000000000001',0,'JUDITH MAQUILING','JUDITH MAQUILING',0,'0000000000000001'),(610,'O','ONION',' ','SPICES','0','','0','','0',2,'1KL',1,60,'2013-07-02 15:09:59','lily','',0,'CD-00000000011','',0,0,'0000000000000003',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000003'),(611,'G','GARLIC',' ','SPICES','0','','0','','0',1,'1KL',1,85,'2013-07-02 15:10:05','lily','',0,'CD-00000000011','',0,0,'0000000000000003',0,'WINBEE MARKETING','0',0,'0000000000000003'),(612,'O','ONION',' ','SPICES','0','','0','','0',1,'1KL',1,60,'2013-07-02 15:19:38',NULL,'',0,NULL,'',0,0,'0000000000000004',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000004'),(613,'G','GARLIC',' ','SPICES','0','','0','','0',1,'1KL',1,85,'2013-07-02 15:22:53',NULL,'',0,NULL,'',0,0,'0000000000000005',0,'WINBEE MARKETING','0',0,'0000000000000005'),(614,'O','ONION',' ','SPICES','0','','0','','0',1,'1KL',1,60,'2013-07-02 15:25:16',NULL,'',0,NULL,'',0,0,'0000000000000006',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000006'),(615,'O','ONION',' ','SPICES','0','','0','','0',1,'1KL',1,60,'2013-07-02 16:20:40',NULL,'',0,NULL,'',0,0,'0000000000000007',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000007'),(616,'O','ONION',' ','SPICES','0','','0','','0',1,'1KL',1,60,'2013-07-02 16:21:42',NULL,'',0,NULL,'',0,0,'0000000000000008',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000008'),(617,'O','ONION',' ','SPICES','0','','0','','0',2,'1KL',1,60,'2013-07-04 11:01:16','lily','',0,'CD-00000000012','',0,0,'0000000000000009',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000009'),(618,'G','GARLIC',' ','SPICES','0','','0','','0',1,'1KL',1,85,'2013-07-04 11:01:21','lily','',0,'CD-00000000012','',0,0,'0000000000000009',0,'WINBEE MARKETING','0',0,'0000000000000009'),(619,'O','ONION',' ','SPICES','0','','0','','0',2,'1KL',1,60,'2013-07-04 11:18:51','lily','',0,'CD-00000000012','',0,0,'0000000000000010',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000010'),(620,'G','GARLIC',' ','SPICES','0','','0','','0',1,'1KL',1,85,'2013-07-04 11:18:55','lily','',0,'CD-00000000012','',0,0,'0000000000000010',0,'WINBEE MARKETING','0',0,'0000000000000010'),(621,'G','GARLIC',' ','SPICES','0','','0','','0',2,'1KL',1,85,'2013-07-04 11:20:03','lily','',0,'CD-00000000012','',0,0,'0000000000000011',0,'WINBEE MARKETING','0',0,'0000000000000011'),(622,'O','ONION',' ','SPICES','0','','0','','0',1,'1KL',1,60,'2013-07-04 11:20:07','lily','',0,'CD-00000000012','',0,0,'0000000000000011',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000011'),(623,'O','ONION',' ','SPICES','0','','0','','0',2,'1KL',1,60,'2013-07-04 15:55:15','lily','',0,'CD-00000000012','',0,0,'0000000000000012',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000012'),(624,'G','GARLIC',' ','SPICES','0','','0','','0',1,'1KL',1,85,'2013-07-04 15:55:20','lily','',0,'CD-00000000012','',0,0,'0000000000000012',0,'WINBEE MARKETING','0',0,'0000000000000012'),(625,'O','ONION',' ','SPICES','0','','0','','0',2,'1KL',1,60,'2013-07-04 15:56:40','lily','',0,'CD-00000000012','',0,0,'0000000000000013',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000013'),(626,'G','GARLIC',' ','SPICES','0','','0','','0',1,'1KL',1,85,'2013-07-04 15:56:43','lily','',0,'CD-00000000012','',0,0,'0000000000000013',0,'WINBEE MARKETING','0',0,'0000000000000013'),(627,'O','ONION',' ','SPICES','0','','0','','0',2,'1KL',1,60,'2013-07-04 16:01:11','lily','',0,'CD-00000000012','',0,0,'0000000000000014',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000014'),(628,'G','GARLIC',' ','SPICES','0','','0','','0',1,'1KL',1,85,'2013-07-04 16:01:13','lily','',0,'CD-00000000012','',0,0,'0000000000000014',0,'WINBEE MARKETING','0',0,'0000000000000014'),(629,'O','ONION',' ','SPICES','0','','0','','0',2,'1KL',1,60,'2013-07-07 22:28:38','lily','',0,'CD-00000000013','',0,0,'0000000000000015',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000015'),(630,'G','GARLIC',' ','SPICES','0','','0','','0',5,'1KL',1,85,'2013-07-07 22:28:41','lily','',0,'CD-00000000013','',0,0,'0000000000000015',0,'WINBEE MARKETING','0',0,'0000000000000015'),(631,'ALUG','ALUGBATI - 1KL',' ','VEGETABLES','0','','0','','0',10,'1KL',1,5,'2013-07-07 22:30:46','lily','',0,'CD-00000000013','',0,0,'0000000000000016',0,'QUIAMCO FARM','0',0,'0000000000000016'),(632,'BB','BAGUIO BEANS - 1KL',' ','VEGETABLES','0','','0','','0',1,'1KL',1,30,'2013-07-07 22:30:50','lily','',0,'CD-00000000013','',0,0,'0000000000000016',0,'QUIAMCO FARM','0',0,'0000000000000016'),(633,'BAL','BALIKATAN RICE - 25KL',' ','RICE','0','','0','','0',1,'25KL',25,924,'2013-07-13 14:59:59','sample','',0,'CD-00000000014','',0,0,'0000000000000017',1,'BM CEREAL','0',0,'0000000000000017'),(634,'G','GARLIC',' ','SPICES','0','','0','','0',5,'1KL',1,85,'2013-07-24 09:32:21','lily','',0,'CD-00000000015','',0,0,'0000000000000018',0,'WINBEE MARKETING','0',0,'0000000000000018'),(635,'O','ONION',' ','SPICES','0','','0','','0',5,'1KL',1,60,'2013-07-24 09:32:26','lily','',0,'CD-00000000015','',0,0,'0000000000000018',0,'WINBEE MARKETING','WINBEE MARKETING',0,'0000000000000018'),(636,'BAN','BANANA - PC',' ','FRUITS','0','','0','','0',10,'PC',1,2.5,'2013-09-02 14:12:06','cashier','',0,'CD-00000000018','',0,0,'0000000000000019',0,'QUIAMCO FARM','0',0,'0000000000000019'),(637,'ALUG','ALUGBATI - 1KL',' ','VEGETABLES','0','','0','','0',10,'1KL',1,5,'2014-01-02 13:20:19','admin','',0,'','',0,0,'0000000000000020',0,'QUIAMCO FARM','0',0,'0000000000000020'),(638,'BB','BAGUIO BEANS - 1KL',' ','VEGETABLES','0','','0','','0',20,'1KL',1,30,'2014-01-02 13:20:23','admin','',0,'','',0,0,'0000000000000020',0,'QUIAMCO FARM','0',0,'0000000000000020'),(639,'ALUG','ALUGBATI - 1KL',' ','VEGETABLES','0','','0','','0',1,'1KL',1,5,'2014-01-08 11:34:36','admin','',0,'','',0,0,'0000000000000021',0,'QUIAMCO FARM','0',0,'0000000000000021'),(640,'BAL','BALIKATAN RICE - 1KL',' ','RICE','0','','0','','0',1,'1KL',1,38.45,'2014-01-08 11:34:41','admin','',0,'','',0,0,'0000000000000021',1,'BM CEREAL','0',0,'0000000000000021'),(641,'AT','ATSAL - 1KL',' ','VEGETABLES','0','','0','','0',1,'1KL',1,100,'2014-01-08 11:41:44','admin','',0,'','',0,0,'0000000000000022',0,'QUIAMCO FARM','0',0,'0000000000000022');
/*!40000 ALTER TABLE `sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_services`
--

DROP TABLE IF EXISTS `sales_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `or_no` varchar(100) DEFAULT NULL,
  `service_name` varchar(100) DEFAULT NULL,
  `service_amount` double DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `session_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_services`
--

LOCK TABLES `sales_services` WRITE;
/*!40000 ALTER TABLE `sales_services` DISABLE KEYS */;
INSERT INTO `sales_services` VALUES (1,'0000000000000015','DELIVERY2',100,'2013-07-07 22:30:40','lily',0,NULL),(2,'0000000000000015','DELIVERY',100,'2013-07-07 22:30:40','lily',0,NULL),(3,'0000000000000016','DELIVERY2',100,'2013-07-07 22:31:08','lily',0,NULL),(4,'0000000000000018','DELIVERY',20,'2013-07-24 09:34:43','lily',0,NULL),(5,'0000000000000020','',0,'2014-01-02 13:21:45','admin',0,NULL);
/*!40000 ALTER TABLE `sales_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'DELIVERY',20),(2,'DELIVERY2',100);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfer`
--

DROP TABLE IF EXISTS `stock_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(500) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `session_no` varchar(500) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `supplier` varchar(500) DEFAULT NULL,
  `supllier_id` varchar(500) DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfer`
--

LOCK TABLES `stock_transfer` WRITE;
/*!40000 ALTER TABLE `stock_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfer_items`
--

DROP TABLE IF EXISTS `stock_transfer_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_no` varchar(500) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `session_no` varchar(500) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `supplier` varchar(500) DEFAULT NULL,
  `supllier_id` varchar(500) DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  `barcode` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `qty` double DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `category` varchar(500) DEFAULT NULL,
  `category_id` varchar(500) DEFAULT NULL,
  `classification` varchar(500) DEFAULT NULL,
  `classification_id` varchar(500) DEFAULT NULL,
  `sub_class` varchar(500) DEFAULT NULL,
  `sub_class_id` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfer_items`
--

LOCK TABLES `stock_transfer_items` WRITE;
/*!40000 ALTER TABLE `stock_transfer_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfer_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier` varchar(100) DEFAULT NULL,
  `contact_no` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'BM CEREAL','',''),(6,'SEA WORLD ','',''),(7,'JUDITH MAQUILING','BANILAD, DUMAGUETE CITY','225-8129'),(8,'NEW BIAN YEK COMMERCIAL','COR. REAL & LOCSIN ST., DUMAGUETE CITY','225-4710'),(9,'S&R MEMBERSHIP','CEBU CITY','09178792854'),(10,'CINDY & NICO DRIED FISH DEALER','CEBU CITY','(032) 418-2118'),(11,'CHENNIES','CEBU CITY','(023) 412-1070'),(12,'JOEBON MARKETING','CALINDAGAN, DUMAGUETE CITY','225-4638'),(13,'WINBEE MARKETING','DUMAGUETE CITY','226-2735'),(14,'BOUNTY FRESH','CALABNUGAN, SIBULAN NEG. OR.','09258086015'),(15,'QUIAMCO FARM','SN. ANTONIO, SIBULAN, NEG. OR.','225-4777');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uom`
--

DROP TABLE IF EXISTS `uom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uom`
--

LOCK TABLES `uom` WRITE;
/*!40000 ALTER TABLE `uom` DISABLE KEYS */;
INSERT INTO `uom` VALUES (1,'PC'),(2,'BOX'),(3,'TRUCK'),(4,'BAG'),(5,'SACK'),(6,'TRAY-6'),(7,'TRAY-12'),(8,'KILO'),(9,'TRAY-30'),(10,'1KL'),(11,'250G'),(12,'2KLS'),(13,'500G'),(14,'25KL'),(15,'50KL'),(16,'TRAY-15');
/*!40000 ALTER TABLE `uom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `screen_name` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `user_level` int(11) DEFAULT NULL,
  `date_added` varchar(100) DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `t_sales` varchar(100) DEFAULT NULL,
  `t_receipts` varchar(100) DEFAULT NULL,
  `t_stock_transfer` varchar(100) DEFAULT NULL,
  `m_items` varchar(100) DEFAULT NULL,
  `m_category` varchar(100) DEFAULT NULL,
  `m_users` varchar(100) DEFAULT NULL,
  `m_uom` varchar(100) DEFAULT NULL,
  `m_suppliers` varchar(100) DEFAULT NULL,
  `r_sales` varchar(100) DEFAULT NULL,
  `r_cash_count` varchar(100) DEFAULT NULL,
  `r_receipts` varchar(100) DEFAULT NULL,
  `r_stock_transferred` varchar(100) DEFAULT NULL,
  `r_stock_take` varchar(100) DEFAULT NULL,
  `m_customers` varchar(100) DEFAULT NULL,
  `m_discount` varchar(100) DEFAULT NULL,
  `m_banks` varchar(100) DEFAULT NULL,
  `r_stock_left_supplier` varchar(100) DEFAULT NULL,
  `t_inventory_adjuster` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'administrator','admin','admin',0,'2013-06-28 17:39:02',1,'1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1'),(5,'rosana','sana','rpm',0,'2013-06-01 11:19:36',1,'1','1','1','1','1','1','1','1','1','1','1','1','1','0','0','0','0','0'),(6,'Cashier Name','cashier','cashier',1,'2013-06-26 09:09:32',1,'1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0'),(7,'Lily Vilando','lily','cano',1,'2013-06-27 14:57:46',1,'1','0','0','0','0','0','0','0','1','0','0','0','0','0','0','1','0','0'),(8,'Lily Vilando','lily1','lily1',1,'2013-06-21 16:19:46',1,'1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','0','0'),(9,'Sample','sample','sample',1,'2013-07-13 14:58:33',1,'1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `void_items`
--

DROP TABLE IF EXISTS `void_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `void_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(500) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `generic_name` varchar(500) DEFAULT NULL,
  `category` varchar(500) DEFAULT NULL,
  `category_id` varchar(500) DEFAULT NULL,
  `classification` varchar(500) DEFAULT NULL,
  `classification_id` varchar(500) DEFAULT NULL,
  `sub_classification` varchar(500) DEFAULT NULL,
  `sub_classification_id` varchar(500) DEFAULT NULL,
  `product_qty` double DEFAULT NULL,
  `unit` varchar(500) DEFAULT NULL,
  `conversion` double DEFAULT NULL,
  `selling_price` double DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `item_type` varchar(500) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `session_no` varchar(500) DEFAULT NULL,
  `item_discount` varchar(500) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discount_amount` double DEFAULT NULL,
  `void_no` varchar(100) DEFAULT NULL,
  `fixed_price` int(11) DEFAULT NULL,
  `supplier` varchar(500) DEFAULT NULL,
  `supplier_id` varchar(500) DEFAULT NULL,
  `vatable` int(11) DEFAULT NULL,
  `or_no` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `void_items`
--

LOCK TABLES `void_items` WRITE;
/*!40000 ALTER TABLE `void_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `void_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voids`
--

DROP TABLE IF EXISTS `voids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `void_no` varchar(100) DEFAULT NULL,
  `date_added` varchar(500) DEFAULT NULL,
  `user_name` varchar(500) DEFAULT NULL,
  `session_no` varchar(500) DEFAULT NULL,
  `gross_amount` double DEFAULT NULL,
  `amount_paid` double DEFAULT NULL,
  `amount_due` double DEFAULT NULL,
  `discount_name` varchar(500) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discount_amount` double DEFAULT NULL,
  `customer_name` varchar(500) DEFAULT NULL,
  `check_bank` varchar(500) DEFAULT NULL,
  `check_no` varchar(500) DEFAULT NULL,
  `check_amount` double DEFAULT NULL,
  `discount_customer_name` varchar(500) DEFAULT NULL,
  `discount_customer_id` varchar(500) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `or_no` varchar(500) DEFAULT NULL,
  `check_holder` varchar(500) DEFAULT NULL,
  `services` varchar(500) DEFAULT NULL,
  `service_amount` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voids`
--

LOCK TABLES `voids` WRITE;
/*!40000 ALTER TABLE `voids` DISABLE KEYS */;
/*!40000 ALTER TABLE `voids` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-29 15:48:47
